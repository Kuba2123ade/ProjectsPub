from database import database
from gui import GUI

data = database()
gui = GUI()