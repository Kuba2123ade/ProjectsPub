const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const app = express();
const jwt = require('jsonwebtoken');
const port = 3001;


let tempKey='';
app.use(cors());
app.use(express.json());



const path = require('path');
let dbPath = path.join(__dirname,'BazaDanych','mydatabase.db');
console.log(`Database path:${dbPath}`);


let db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error(err.message);
    }
    console.log('Connected to the database.');
});

app.post('/login', (req, res) => {
    const { login, haslo } = req.body;

    db.get('SELECT * FROM Pracownik WHERE Login = ?', [login], (err, row) => {
        if (err) {
            console.error('Error querying database:', err.message);
            res.status(500).json({ error: 'Internal Server Error' });
        } else {
            if (row) {
                if (haslo === row.Haslo) {
                    const payload = {
                        id: row.Id,
                        role: row.Rola
                    };

                    const token = jwt.sign(payload, 'tajnyKlucz', { expiresIn: '1h' });
                    tempKey=token;
                    res.json({ success: true, token });
                } else {
                    res.status(401).json({ error: 'Invalid credentials' });
                }
            } else {
                res.status(401).json({ error: 'Invalid credentials' });
            }
        }
    });
});



const verifyToken = (req, res, next) => {
    const token = req.header('Authorization');

    if (!token) {
        return res.status(401).json({ error: 'Unauthorized' });
    }

    const tokenWithoutBearer = token.replace('Bearer ', '');

    jwt.verify(tokenWithoutBearer, 'tajnyKlucz', (err, decoded) => {
        if (err) {
            return res.status(401).json({ error: 'Unauthorized' });
        }
        req.Id = decoded.id;
        req.Rola = decoded.role;
        next();
    });
};

app.get('/protected-resource', verifyToken, (req, res) => {
    console.log("otrzymane id:"+req.Id )
    res.json({ message: 'Protected resource accessed successfully',Id: req.Id,
        Rola: req.Rola });
});

app.get('/employees', (req, res) => {
    let sql = `SELECT * FROM Pracownik`;
    db.all(sql, [], (err, rows) => {
        if (err) {
            throw err;
        }
        console.log(rows)
        res.send(rows);
    });
});

app.get('/employees/:id', (req, res) => {
    const employeeId = req.params.id;

    const sqlGetEmployee = `SELECT * FROM Pracownik WHERE Id = ?`;

    db.get(sqlGetEmployee, [employeeId], (err, row) => {
        if (err) {
            console.error(err.message);
            res.status(500).send('Failed to get employee');
        } else {
            if (!row) {
                res.status(404).send('Employee not found');
            } else {
                res.status(200).json(row);
            }
        }
    });
});

app.post('/employees', (req, res) => {
    const { Imie, Nazwisko, Email, Data_zatrudnienia, Szef, Haslo, Rola, Login } = req.body;

    const sqlCheckEmployeeExists = `
        SELECT Id FROM Pracownik
        WHERE Imie = ? AND Nazwisko = ? AND Email = ? AND Login = ?
    `;

    db.get(sqlCheckEmployeeExists, [Imie, Nazwisko, Email, Login], (err, row) => {
        if (err) {
            console.error(err.message);
            res.status(500).json({ error: 'Failed to add employee' });
            return;
        }

        if (row) {
            console.log('Employee with the same name, email, and login already exists');
            res.status(409).json({ error: 'Employee with the same name, email, and login already exists' });
            return;
        }

        const sqlCheckLoginExists = `
            SELECT Id FROM Pracownik
            WHERE Login = ?
        `;

        db.get(sqlCheckLoginExists, [Login], (err, loginRow) => {
            if (err) {
                console.error(err.message);
                res.status(500).json({ error: 'Failed to add employee' });
                return;
            }

            if (loginRow) {
                console.log('Login is already taken');
                res.status(409).json({ error: 'Login is already taken' });
                return;
            }

            const sqlGetMaxId = `SELECT MAX(Id) AS maxId FROM Pracownik`;

            db.get(sqlGetMaxId, [], (err, row) => {
                if (err) {
                    console.error(err.message);
                    res.status(500).json({ error: 'Failed to add employee' });
                    return;
                }

                const newId = row.maxId ? row.maxId + 1 : 1;

                const sqlInsertEmployee = `
                    INSERT INTO Pracownik (Id, Imie, Nazwisko, Email, Data_zatrudnienia, Szef, Haslo, Rola, Login)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                `;

                db.run(sqlInsertEmployee, [newId, Imie, Nazwisko, Email, Data_zatrudnienia, Szef, Haslo, Rola, Login], function (err) {
                    if (err) {
                        console.error(err.message);
                        res.status(500).json({ error: 'Failed to add employee' });
                    } else {
                        console.log('Employee added successfully with ID:', newId);
                        res.status(200).json({ id: newId });
                    }
                });
            });
        });
    });
});



app.delete('/employees/:id', (req, res) => {
    const employeeId = req.params.id;
    const sqlCheckEmployee = `SELECT * FROM Pracownik WHERE Id = ?`;

    db.get(sqlCheckEmployee, [employeeId], (err, row) => {
        if (err) {
            console.error(err.message);
            return res.status(500).json({message: 'Failed to delete employee'});
        }

        if (!row) {
            return res.status(404).json({message: 'Employee not found'});
        }

        if (row.Rola === 3) {
            const sqlCheckAdmins = `SELECT COUNT(*) as count FROM Pracownik WHERE Rola = 3`;
            db.get(sqlCheckAdmins, [], (err, result) => {
                if (err) {
                    console.error(err.message);
                    return res.status(500).json({message: 'Failed to check admins'});
                }
                if (result.count <= 1) {
                    console.log("He is the only admin in system!")
                    return res.status(400).json({message: 'Cannot delete the only admin'});
                } else {
                    deleteEmployee(employeeId, res);
                }
            });
        } else {
            deleteEmployee(employeeId, res);
        }
    });
});

function deleteEmployee(employeeId, res) {
    const sqlDeleteAssignments = `DELETE FROM Pracownik_Projekt WHERE Pracownik_Id = ?`;
    db.run(sqlDeleteAssignments, [employeeId], (err) => {
        if (err) {
            console.error(err.message);
            return res.status(500).json({message: 'Failed to delete project assignments'});
        }

        const sqlUpdateEmployees = `UPDATE Pracownik SET Szef = NULL WHERE Szef = ?`;
        db.run(sqlUpdateEmployees, [employeeId], (err) => {
            if (err) {
                console.error(err.message);
                return res.status(500).json({message: 'Failed to update employees'});
            }

            const sqlUpdateProjects = `UPDATE Projekt SET Szef_Id = NULL WHERE Szef_Id = ?`;
            db.run(sqlUpdateProjects, [employeeId], (err) => {
                if (err) {
                    console.error(err.message);
                    return res.status(500).json({message: 'Failed to update projects'});
                }

                const sqlDeleteEmployee = `DELETE FROM Pracownik WHERE Id = ?`;
                db.run(sqlDeleteEmployee, [employeeId], (err) => {
                    if (err) {
                        console.error(err.message);
                        return res.status(500).json({message: 'Failed to delete employee'});
                    } else {
                        console.log('Employee deleted successfully with ID:', employeeId);
                        return res.status(200).json({message: 'Employee deleted successfully'});
                    }
                });
            });
        });
    });
}






app.put('/employees/:id', (req, res) => {
    const employeeId = req.params.id;
    const { Imie, Nazwisko, Email, Data_zatrudnienia, Szef, Login, Haslo, Rola } = req.body;

    const sqlCheckEmployee = `
        SELECT Rola FROM Pracownik
        WHERE Id = ?
    `;

    db.get(sqlCheckEmployee, [employeeId], (err, result) => {
        if (err) {
            console.error(err.message);
            res.status(500).json({ message: 'Failed to update employee' });
            return;
        }

        if (!result) {
            res.status(404).json({ message: 'Employee not found' });
            return;
        }

        const currentRole = result.Rola;

        const sqlCheckEmployeeExists = `
            SELECT Id FROM Pracownik
            WHERE (Imie = ? AND Nazwisko = ? AND Email = ? AND Rola = ? AND Id <> ?) OR (Login = ? AND Id <> ?)
        `;

        db.get(sqlCheckEmployeeExists, [Imie, Nazwisko, Email, Rola, employeeId, Login, employeeId], (err, row) => {
            if (err) {
                console.error(err.message);
                res.status(500).json({ message: 'Failed to update employee' });
                return;
            }

            if (row) {
                if (row.Login === Login) {
                    console.log('Login already taken');
                    res.status(409).json({ message: 'Login already taken' });
                } else {
                    console.log('Employee with the same name, surname, email, role, or login already exists ');
                    res.status(409).json({ message: 'Employee with the same name, surname, email, role, or login already exists' });
                }
                return;
            }

            const sqlUpdateSubordinates = `
                UPDATE Pracownik
                SET Szef = NULL
                WHERE Szef = ?
            `;

            db.run(sqlUpdateSubordinates, [employeeId], (err) => {
                if (err) {
                    console.error(err.message);
                    res.status(500).json({ message: 'Failed to update subordinates' });
                    return;
                }

                if (currentRole === 3 && Rola !== 3) {
                    const sqlCheckAdminCount = `
                        SELECT COUNT(*) AS AdminCount
                        FROM Pracownik
                        WHERE Rola = 3
                    `;
                    db.get(sqlCheckAdminCount, [], (err, result) => {
                        if (err) {
                            console.error(err.message);
                            res.status(500).json({ message: 'Failed to check admin count' });
                            return;
                        }

                        const adminCount = result.AdminCount;

                        if (adminCount === 1 && (Rola === 1 || Rola === 2)) {
                            res.status(403).json({ message: 'Cannot change role. The user is the only administrator.' });
                            return;
                        }

                        const sqlUpdateEmployee = `
                            UPDATE Pracownik
                            SET Imie = ?, Nazwisko = ?, Email = ?, Data_zatrudnienia = ?, Szef = ?, Login = ?, Haslo = ?, Rola = ?
                            WHERE Id = ?
                        `;

                        db.run(
                            sqlUpdateEmployee,
                            [Imie, Nazwisko, Email, Data_zatrudnienia, Szef, Login, Haslo, Rola, employeeId],
                            (err) => {
                                if (err) {
                                    console.error(err.message);
                                    res.status(500).json({ message: 'Failed to update employee' });
                                } else {
                                    console.log('Employee updated successfully with ID:', employeeId);
                                    res.status(200).json({ message: 'Employee updated successfully' });
                                }
                            }
                        );
                    });
                } else {
                    const sqlUpdateEmployee = `
                        UPDATE Pracownik
                        SET Imie = ?, Nazwisko = ?, Email = ?, Data_zatrudnienia = ?, Szef = ?, Login = ?, Haslo = ?, Rola = ?
                        WHERE Id = ?
                    `;

                    db.run(
                        sqlUpdateEmployee,
                        [Imie, Nazwisko, Email, Data_zatrudnienia, Szef, Login, Haslo, Rola, employeeId],
                        (err) => {
                            if (err) {
                                console.error(err.message);
                                res.status(500).json({ message: 'Failed to update employee' });
                            } else {
                                console.log('Employee updated successfully with ID:', employeeId);
                                res.status(200).json({ message: 'Employee updated successfully' });
                            }
                        }
                    );
                }
            });
        });
    });
});









app.get('/employee/:id/projects', (req, res) => {
    const employeeId = req.params.id;

    const sqlGetEmployeeProjects = `
        SELECT Pracownik.Imie, Pracownik.Nazwisko, Projekt.Nazwa AS Projekt_Nazwa, Pracownik_Projekt.Rola
        FROM Pracownik_Projekt
        JOIN Pracownik ON Pracownik.Id = Pracownik_Projekt.Pracownik_Id
        JOIN Projekt ON Projekt.Id = Pracownik_Projekt.Projekt_Id
        WHERE Pracownik.Id = ?
    `;

    db.all(sqlGetEmployeeProjects, [employeeId], (err, rows) => {
        if (err) {
            console.error(err.message);
            res.status(500).send('Failed to fetch employee projects');
        } else {
            console.table(rows);
            res.status(200).json(rows);
        }
    });
});

app.get('/projects', (req, res) => {
    let sql = `SELECT Id, Nazwa, Poczatek_Proj, Koniec_Projektu, Szef_Id FROM Projekt`;
    db.all(sql, [], (err, rows) => {
        if (err) {
            throw err;
        }
        console.log(rows);
        res.send(rows);
    });
});

app.post('/projects', (req, res) => {
    const { Nazwa, Poczatek_Proj, Koniec_Projektu, Szef_Id } = req.body;

    // Check if project with the same name already exists
    const sqlCheckProjectExists = `
        SELECT Id FROM Projekt
        WHERE Nazwa = ?
    `;

    db.get(sqlCheckProjectExists, [Nazwa], (err, row) => {
        if (err) {
            console.error(err.message);
            res.status(500).json({ error: 'Failed to add project' });
            return;
        }

        if (row) {
            console.log('Project with the same name already exists');
            res.status(409).json({ error: 'Project with the same name already exists' });
            return;
        }

        const sqlGetMaxId = `SELECT MAX(Id) AS maxId FROM Projekt`;

        db.get(sqlGetMaxId, [], (err, row) => {
            if (err) {
                console.error(err.message);
                res.status(500).json({ error: 'Failed to add project' });
                return;
            }

            const newId = row.maxId ? row.maxId + 1 : 1;

            const sqlInsertProject = `
                INSERT INTO Projekt (Id, Nazwa, Poczatek_Proj, Koniec_Projektu, Szef_Id)
                VALUES (?, ?, ?, ?, ?)
            `;

            db.run(sqlInsertProject, [newId, Nazwa, Poczatek_Proj, Koniec_Projektu, Szef_Id], function (err) {
                if (err) {
                    console.error(err.message);
                    res.status(500).json({ error: 'Failed to add project' });
                } else {
                    console.log('Project added successfully with ID:', newId);
                    res.status(200).json({ id: newId });
                }
            });
        });
    });
});
app.delete('/projects/:id', (req, res) => {
    const projectId = req.params.id;

    const sqlCheckProjectExists = `
        SELECT Id FROM Projekt
        WHERE Id = ?
    `;

    db.get(sqlCheckProjectExists, [projectId], (err, row) => {
        if (err) {
            console.error(err.message);
            res.status(500).json({ error: 'Failed to delete project' });
            return;
        }

        if (!row) {
            console.log('Project with the specified ID does not exist');
            res.status(404).json({ error: 'Project not found' });
            return;
        }

        const sqlDeletePracownikProjekt = `
            DELETE FROM Pracownik_Projekt
            WHERE Projekt_Id = ?
        `;

        db.run(sqlDeletePracownikProjekt, [projectId], function (err) {
            if (err) {
                console.error(err.message);
                res.status(500).json({ error: 'Failed to delete project-related entries from Pracownik_Projekt' });
                return;
            }

            const sqlDeleteProject = `
                DELETE FROM Projekt
                WHERE Id = ?
            `;

            db.run(sqlDeleteProject, [projectId], function (err) {
                if (err) {
                    console.error(err.message);
                    res.status(500).json({ error: 'Failed to delete project' });
                } else {
                    console.log('Project deleted successfully with ID:', projectId);
                    res.status(200).json({ message: 'Project deleted successfully' });
                }
            });
        });
    });
});

app.put('/projects/:id', (req, res) => {
    const projectId = req.params.id;
    const { Nazwa, Poczatek_Proj, Koniec_Projektu, Szef_Id } = req.body;

    const sqlCheckProjectExists = `
        SELECT Id FROM Projekt
        WHERE Nazwa = ? AND Id <> ?
    `;

    db.get(sqlCheckProjectExists, [Nazwa, projectId], (err, row) => {
        if (err) {
            console.error(err.message);
            res.status(500).json({ message: 'Failed to update project' });
            return;
        }

        if (row) {
            console.log('Project with the same name already exists');
            res.status(409).json({ message: 'Project with the same name already exists' });
            return;
        }
        const sqlUpdateProject = `
            UPDATE Projekt
            SET Nazwa = ?, Poczatek_Proj = ?, Koniec_Projektu = ?, Szef_Id = ?
            WHERE Id = ?
        `;

        db.run(sqlUpdateProject, [Nazwa, Poczatek_Proj, Koniec_Projektu, Szef_Id, projectId], (err) => {
            if (err) {
                console.error(err.message);
                res.status(500).json({ message: 'Failed to update project' });
            } else {
                console.log('Project updated successfully with ID:', projectId);
                res.status(200).json({ message: 'Project updated successfully' });
            }
        });
    });
});

app.get('/projects/:id', (req, res) => {
    const projectId = req.params.id;

    const sqlGetProjectWithBoss = `
        SELECT Projekt.*, Pracownik.Imie AS Szef_Imie, Pracownik.Nazwisko AS Szef_Nazwisko, Pracownik.Email AS Szef_Email
        FROM Projekt
                 LEFT JOIN Pracownik ON Projekt.Szef_Id = Pracownik.Id
        WHERE Projekt.Id = ?
    `;

    db.get(sqlGetProjectWithBoss, [projectId], (err, row) => {
        if (err) {
            console.error(err.message);
            res.status(500).send('Failed to fetch project details');
        } else {
            if (!row) {
                res.status(404).send('Project not found');
            } else {
                res.status(200).json(row);
            }
        }
    });
});

app.get('/projects/:id/employees', (req, res) => {
    const projectId = req.params.id;

    const sqlGetProjectEmployees = `
        SELECT Pracownik.Id, Pracownik.Imie, Pracownik.Nazwisko, Pracownik.Email, Pracownik_Projekt.Rola
        FROM Pracownik
        JOIN Pracownik_Projekt ON Pracownik.Id = Pracownik_Projekt.Pracownik_Id
        WHERE Pracownik_Projekt.Projekt_Id = ?
    `;

    db.all(sqlGetProjectEmployees, [projectId], (err, rows) => {
        if (err) {
            console.error(err.message);
            res.status(500).send('Failed to fetch project employees');
        } else {
            res.status(200).json(rows);
        }
    });
});

app.post('/employeeProjects', (req, res) => {
    const { Pracownik_Id, Projekt_Id, Rola } = req.body;

    const sqlCheckAssignmentExists = `
        SELECT Id FROM Pracownik_Projekt
        WHERE Pracownik_Id = ? AND Projekt_Id = ? AND Rola = ?
    `;

    db.get(sqlCheckAssignmentExists, [Pracownik_Id, Projekt_Id, Rola], (err, row) => {
        if (err) {
            console.error(err.message);
            res.status(500).json({ error: 'Failed to check employee assignment to project' });
            return;
        }

        if (row) {
            console.log('Employee assignment to project with the same role already exists');
            res.status(409).json({ error: 'Employee assignment to project with the same role already exists' });
            return;
        }

        const sqlInsertAssignment = `
            INSERT INTO Pracownik_Projekt (Pracownik_Id, Projekt_Id, Rola)
            VALUES (?, ?, ?)
        `;

        db.run(sqlInsertAssignment, [Pracownik_Id, Projekt_Id, Rola], function(err) {
            if (err) {
                console.error(err.message);
                res.status(500).json({ error: 'Failed to add employee to project' });
            } else {
                console.log('Employee added to project successfully with ID:', this.lastID);
                res.status(200).json({ id: this.lastID });
            }
        });
    });
});

app.get('/employee-project/:id', (req, res) => {
    const assignmentId = req.params.id;

    const sqlGetEmployeeProject = `
        SELECT * FROM Pracownik_Projekt WHERE Id = ?
    `;

    db.get(sqlGetEmployeeProject, [assignmentId], (err, row) => {
        if (err) {
            console.error(err.message);
            res.status(500).send('Failed to fetch employee project');
        } else {
            if (!row) {
                res.status(404).send('Employee project not found');
            } else {
                res.status(200).json(row);
            }
        }
    });
});

app.put('/employee-project/:id', (req, res) => {
    const assignmentId = req.params.id;
    const { Pracownik_Id, Projekt_Id, Rola } = req.body;

    const sqlCheckAssignmentExists = `
        SELECT Id FROM Pracownik_Projekt
        WHERE Pracownik_Id = ? AND Projekt_Id = ? AND Rola = ? AND Id <> ?
    `;

    db.get(sqlCheckAssignmentExists, [Pracownik_Id, Projekt_Id, Rola, assignmentId], (err, row) => {
        if (err) {
            console.error(err.message);
            res.status(500).json({ message: 'Failed to update employee project' });
            return;
        }

        if (row) {
            console.log('Employee assignment to project with the same role already exists');
            res.status(409).json({ message: 'Employee assignment to project with the same role already exists' });
            return;
        }

        const sqlUpdateAssignment = `
            UPDATE Pracownik_Projekt
            SET Pracownik_Id = ?, Projekt_Id = ?, Rola = ?
            WHERE Id = ?
        `;

        db.run(sqlUpdateAssignment, [Pracownik_Id, Projekt_Id, Rola, assignmentId], (err) => {
            if (err) {
                console.error(err.message);
                res.status(500).json({ message: 'Failed to update employee project' });
            } else {
                console.log('Employee project updated successfully with ID:', assignmentId);
                res.status(200).json({ message: 'Employee project updated successfully' });
            }
        });
    });
});

app.get('/projects/:id/employees', (req, res) => {
    const projectId = req.params.id;

    const sqlGetProjectEmployees = `
        SELECT Pracownik.Id, Pracownik.Imie, Pracownik.Nazwisko, Pracownik.Email, Pracownik_Projekt.Rola
        FROM Pracownik
        JOIN Pracownik_Projekt ON Pracownik.Id = Pracownik_Projekt.Pracownik_Id
        WHERE Pracownik_Projekt.Projekt_Id = ?
    `;

    db.all(sqlGetProjectEmployees, [projectId], (err, rows) => {
        if (err) {
            console.error(err.message);
            res.status(500).send('Failed to fetch project employees');
        } else {
            res.status(200).json(rows);
        }
    });
});

app.get('/employeeProjects', (req, res) => {
    const sqlGetEmployeeProjects = `
        SELECT Pracownik_Projekt.Id, Pracownik.Imie, Pracownik.Nazwisko, Pracownik.Szef , Projekt.Nazwa AS Projekt_Nazwa, Pracownik_Projekt.Rola
        FROM Pracownik_Projekt
                 JOIN Pracownik ON Pracownik.Id = Pracownik_Projekt.Pracownik_Id
                 JOIN Projekt ON Projekt.Id = Pracownik_Projekt.Projekt_Id
    `;

    db.all(sqlGetEmployeeProjects, [], (err, rows) => {
        if (err) {
            console.error(err.message);
            res.status(500).send('Failed to fetch employee projects');
        } else {
            res.status(200).json(rows);
        }
    });
});

app.delete('/employeeProjects/:id', (req, res) => {
    const assignmentId = req.params.id;

    const sqlCheckAssignmentExists = `
        SELECT * FROM Pracownik_Projekt
        WHERE Id = ?
    `;

    db.get(sqlCheckAssignmentExists, [assignmentId], (err, row) => {
        if (err) {
            console.error(err.message);
            res.status(500).json({ success: false, message: 'Failed to check employee project assignment existence' });
            return;
        }

        if (!row) {
            res.status(404).json({ success: false, message: 'Employee project assignment not found' });
            return;
        }

        const sqlDeleteEmployeeProject = `
            DELETE FROM Pracownik_Projekt
            WHERE Id = ?
        `;

        db.run(sqlDeleteEmployeeProject, [assignmentId], (err) => {
            if (err) {
                console.error(err.message);
                res.status(500).json({ success: false, message: 'Failed to delete employee project assignment' });
            } else {
                console.log('Employee project assignment deleted successfully with ID:', assignmentId);
                res.status(200).json({ success: true, message: 'Employee project assignment deleted successfully' });
            }
        });
    });
});


app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
