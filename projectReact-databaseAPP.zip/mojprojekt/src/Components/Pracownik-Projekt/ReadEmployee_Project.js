import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import './CSS/ReadEmployee_Project.css';

export const Employees_Project = () => {


    const [pracownicyProjekty, setPracownicyProjekty] = useState([]);
    const navigate = useNavigate();
    const [userRole, setUserRole] = useState('');
    const [idUser, setidUser] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(5);

    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    let currentItems = pracownicyProjekty.slice(indexOfFirstItem, indexOfLastItem);

    const paginate = (pageNumber) => {
        setCurrentPage(pageNumber);
    };

    useEffect(() => {
        const token = localStorage.getItem('token');
        if (!token) {
            return;
        }

        fetch('http://localhost:3001/protected-resource', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        })
            .then(response => response.json())
            .then(data => {
                if (data.Rola && data.Rola !== 3 && data.Rola !== 2) {
                    return;
                }
                setidUser(data.Id);
                setUserRole(data.Rola);
            })
            .catch(error => console.error(error));
    }, []);

    useEffect(() => {
        const token = localStorage.getItem('token');
        if (!token) {
            return;
        }

        fetch('http://localhost:3001/employeeProjects')
            .then(response => response.json())
            .then(data => {
                let filteredData;
                if (String(userRole) === String(3)) {
                    filteredData = data;
                } else {
                    filteredData = data.filter(pracownik => pracownik.Szef === idUser);
                }
                setPracownicyProjekty(filteredData);
            })
            .catch(error => console.error(error));
    }, [idUser, userRole]);

    const handleDelete = (id) => {
        fetch(`http://localhost:3001/employeeProjects/${id}`, {
            method: 'DELETE',
        })
            .then(response => {
                if (response.ok) {
                    return response.json();
                } else {
                    throw new Error('Failed to delete Pracownik_Projekt');
                }
            })
            .then(data => {
                console.log('Pracownik_Projekt deleted successfully');
                setPracownicyProjekty(prevItems => prevItems.filter(item => item.Id !== id));
            })
            .catch(error => console.error(error));
    };

    const handleModify = (id) => {
        navigate(`/UpdateEmployee_Project/${id}`);
    };

    return (
        <div>
            <Link to="/" className="button green-button">Powrót do Strony Głównej</Link>
            {userRole === 3 || userRole === 2 ? (
                <>
                    <Link to="/CreateEmployees_Project" className="button black-button">Dodaj Pracownika do Projektu</Link>
                    <h1>Lista Pracowników w Projektach</h1>
                    {pracownicyProjekty.length > 0 ? (
                        <>
                            <ul>
                                {currentItems.map((employee) => (
                                    <li key={employee.Id}>
                                        <table className="custom-table">
                                            <tbody>
                                            <Link to={`/EmployeeProjectDetails/${employee.Id}`} className="employee-link">
                                            <tr>
                                                        {`Imie: ${employee.Imie}`}
                                            </tr>
                                                <tr>
                                                    {`Nazwisko: ${employee.Nazwisko}`}
                                                </tr>
                                            <tr>
                                                        {`Nazwa Projektu: ${employee.Projekt_Nazwa}`}
                                            </tr>
                                            </Link>
                                            </tbody>
                                        </table>
                                        <div>
                                            <button onClick={() => handleModify(employee.Id)}>Modyfikuj</button>
                                            <button onClick={() => handleDelete(employee.Id)}>Usuń</button>
                                        </div>
                                    </li>
                                ))}
                            </ul>

                            <div className="pagination">
                                {Array.from({ length: Math.ceil(pracownicyProjekty.length / itemsPerPage) }, (_, index) => (
                                    <button key={index + 1} onClick={() => paginate(index + 1)}>
                                        {index + 1}
                                    </button>
                                ))}
                            </div>
                        </>
                    ) : (
                        <p>Brak pracowników</p>
                    )}
                </>
            ) : (
                <p>{"Brak dostepu"}</p>
            )}
        </div>
    );
};
