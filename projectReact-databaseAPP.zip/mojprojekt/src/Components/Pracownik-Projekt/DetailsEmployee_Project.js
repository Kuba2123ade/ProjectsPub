import React, { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';

import './CSS/DetailEmployee_Project.css';
export const EmployeeProjectDetails = () => {
    const { id } = useParams();
    const [employeeProject, setEmployeeProject] = useState(null);
    const [employee, setEmployee] = useState(null);
    const [project, setProject] = useState(null);
    const [loading, setLoading] = useState(true);
    const [userRole, setUserRole] = useState('');

    useEffect(() => {
        const token = localStorage.getItem('token');
        if (!token) {
            return;
        }

        fetch('http://localhost:3001/protected-resource', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        })
            .then(response => response.json())
            .then(data => {
                if (data.Rola && data.Rola !== 3 && data.Rola !== 2) {
                    return;
                }
                setUserRole(data.Rola);
        fetch(`http://localhost:3001/employee-project/${id}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Failed to fetch employee project');
                }
                return response.json();
            })
            .then(data => {
                setEmployeeProject(data);
                setLoading(false);

                // Fetch employee data
                fetch(`http://localhost:3001/employees/${data.Pracownik_Id}`)
                    .then(response => response.json())
                    .then(employeeData => setEmployee(employeeData))
                    .catch(error => console.error('Failed to fetch employee', error));

                // Fetch project data
                fetch(`http://localhost:3001/projects/${data.Projekt_Id}`)
                    .then(response => response.json())
                    .then(projectData => setProject(projectData))
                    .catch(error => console.error('Failed to fetch project', error));
            })
            .catch(error => {
                console.error(error.message);
                setLoading(false);
            });
            })
            .catch(error => console.error(error));
    }, [id]);

    return (
        <div>
            {userRole===3 || userRole===2? (
                <>
            <nav>
                <Link to="/Employees_Project">Powrót do widoku wszystkich projektów pracownika</Link>
            </nav>
            <h2>Szczegóły przypisania pracownika do projektu</h2>
            {loading ? (
                <p>Ładowanie danych...</p>
            ) : employeeProject ? (
                <table>
                    <tbody>
                    <tr>
                        <td>Pracownik</td>
                        <td>{employee ? `${employee.Imie} ${employee.Nazwisko} (${employee.Email})` : 'Brak danych'}</td>
                    </tr>
                    <tr>
                        <td>Projekt</td>
                        <td>{project ? `${project.Nazwa} (${project.Poczatek_Proj? project.Poczatek_Proj : 'Nie ustalono początku projektu'} do ${project.Koniec_Projektu? project.Koniec_Projektu : 'Nie ustalono końca projektu'}`+ ')' : 'Brak danych'}</td>
                    </tr>
                    <tr>
                        <td>Rola</td>
                        <td>{employeeProject.Rola}</td>
                    </tr>
                    </tbody>
                </table>
            ) : (
                <p>Przypisanie pracownika do projektu nie zostało znalezione.</p>
            )}
                </>
            ) : (
                <p>{"Brak dostepu"}</p>
            )}
        </div>
    );
};
