import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import './CSS/CreateEmployee_Project.css';

export const CreateEmployee_Project = () => {
    const [employees, setEmployees] = useState([]);
    const [projects, setProjects] = useState([]);
    const [message, setMessage] = useState('');
    const [statusMessage, setStatusMessage] = useState('');
    const [userRole, setUserRole] = useState('');
    const [formData, setFormData] = useState({
        Pracownik_Id: '',
        Projekt_Id: '',
        Rola: '',
    });

    const fetchEmployees = (id, rola) => {

        fetch(`http://localhost:3001/employees`)
            .then((response) => response.json())
            .then((data) => {
                if(String(rola)==='3')
                    setEmployees(data);
                    else
                setEmployees(data.filter(pracownik => pracownik.Szef === id));
            })
            .catch((error) => console.error(error));
    };

    const fetchProjects = () => {
        fetch(`http://localhost:3001/projects`)
            .then((response) => response.json())
            .then((data) => {
                setProjects(data);
            })
            .catch((error) => console.error(error));
    };

    useEffect(() => {
        const token = localStorage.getItem('token');
        if (!token) {
            setMessage('Brak dostępu');
            return;
        }

        fetch('http://localhost:3001/protected-resource', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        })
            .then(response => response.json())
            .then(data => {
                if (data.Rola && data.Rola !== 3 && data.Rola !== 2) {
                    setMessage('Brak dostępu');
                    return;
                }
                setUserRole(data.Rola);
        fetchEmployees(data.Id,data.Rola);
        fetchProjects();
            })
            .catch(error => console.error(error));
    }, []);

    const handleInputChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };

    const handleSelectEmployee = () => {
        fetchEmployees();
    };

    const handleSelectProject = () => {
        fetchProjects();
    };

    const handleSubmit = async () => {
        try {
            setStatusMessage('');
            setMessage('');

            if (formData.Rola.trim().length === 0 || formData.Rola.length > 30) {
                setMessage('Pole Rola nie może być puste i musi mieć mniej niż 30 znaków.');
                return;
            }
            if (!formData.Pracownik_Id || !formData.Projekt_Id) {
                setMessage("Pracownik i projekt muszą zostać wybrani!");
                return;
            }

            const response = await fetch('http://localhost:3001/employeeProjects', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData),
            });

            if (response.ok) {
                setFormData({
                    Pracownik_Id: '',
                    Projekt_Id: '',
                    Rola: '',
                });

                const result = await response.json();
                console.log('Employee added to project successfully with ID:', result.id);
                setStatusMessage('Pracownik dodany do projektu pomyślnie.');
            } else {
                console.error('Failed to add employee to project');
                setStatusMessage('Błąd podczas dodawania pracownika do projektu.');
            }
        } catch (error) {
            console.error('Error adding employee to project:', error);
            setStatusMessage('Wystąpił błąd podczas komunikacji z serwerem.');
        }
    };

    return (
        <div>
            {userRole===3 || userRole===2? (
                <>
            <nav>
                <Link to="/Employees_Project">Powrót do widoku wszystkich powiązań pracowników z projektami</Link>
            </nav>
            <h2>Formularz dodawania pracownika do projektu</h2>
            <div>
                <label>Pracownik:</label><br />

                <select name="Pracownik_Id" onChange={handleInputChange} value={formData.Pracownik_Id}>
                    <option value="" onClick={handleSelectEmployee}>Wybierz pracownika</option>
                    {employees.map((employee) => (
                        <option key={employee.Id} value={employee.Id}>
                            {employee.Imie} {employee.Nazwisko} {employee.Email}
                        </option>
                    ))}
                </select>
                <br />
                <label>Projekt:</label><br />
                <select name="Projekt_Id" onChange={handleInputChange} value={formData.Projekt_Id}>
                    <option value="" onClick={handleSelectProject}>Wybierz projekt</option>
                    {projects.map((project) => (
                        <option key={project.Id} value={project.Id}>
                            {project.Nazwa}
                        </option>
                    ))}
                </select>
                <br />
                <label>Rola:</label><br />
                <input type="text" name="Rola" value={formData.Rola} onChange={handleInputChange} />
                <br />
                <button onClick={handleSubmit}>Dodaj pracownika do projektu</button>
                {message && <p style={{ color: 'red' }}>{message}</p>}
                {statusMessage && <p style={{ color: 'green' }}>{statusMessage}</p>}
            </div>
                </>
            ) : (
                <p>{"Brak dostepu"}</p>
            )}
        </div>
    );
};
