import React, { useState, useEffect } from 'react';
import { Link, useParams} from 'react-router-dom';

export const UpdateEmployeeProject = () => {
    const { id } = useParams();
    const [userRole, setUserRole] = useState('');
    const [idUser, setidUser] = useState('');
    const [userId, setuserId] = useState('');
    const [assignment, setAssignment] = useState({
        Pracownik_Id: '',
        Projekt_Id: '',
        Rola: '',
    });

    const [projects, setProjects] = useState([]);
    const [employees, setEmployees] = useState([]);
    const [message, setMessage] = useState('');

    useEffect(() => {
        const token = localStorage.getItem('token');
        if (!token) {
            setMessage('Brak dostępu');
            return;
        }

        fetch('http://localhost:3001/protected-resource', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        })
            .then(response => response.json())
            .then(data => {
                if (data.Rola && data.Rola !== 3 && data.Rola !== 2) {
                    setMessage('Brak dostępu');
                    return;
                }
                setUserRole(data.Rola);
                setuserId(data.Id);
        fetch(`http://localhost:3001/employee-project/${id}`)
            .then((response) => response.json())
            .then((data) => setAssignment(data))
            .catch((error) => console.error(error));

        fetch(`http://localhost:3001/projects`)
            .then((response) => response.json())
            .then((data) => setProjects(data))
            .catch((error) => console.error(error));


            })
            .catch(error => console.error(error));
    }, [id]);
    useEffect(() => {
        const token = localStorage.getItem('token');
        if (!token) {
            return;
        }

        fetch('http://localhost:3001/employeeProjects')
            .then(response => response.json())
            .then(data => {
                let filteredData;
                if (String(userRole) === String(3)) {
                    filteredData = data;
                } else {
                    filteredData = data.filter(pracownik => pracownik.Szef === idUser);
                }
                setEmployees(filteredData);
            })
            .catch(error => console.error(error));
        fetch(`http://localhost:3001/employees`)
            .then((response) => response.json())
            .then((data) => {
                if(String(userRole)==='3')
                    setEmployees(data)
                else setEmployees(data.filter(pracownik => pracownik.Szef === userId));



            })
            .catch((error) => console.error(error));
    }, [idUser, userRole]);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setAssignment({
            ...assignment,
            [name]: value,
        });
    };

    const handleUpdate = () => {
        setMessage('');

        if (!assignment.Pracownik_Id) {
            setMessage("Wybierz pracownika!");
            return;
        }
        if (!assignment.Projekt_Id) {
            setMessage("Wybierz projekt!");
            return;
        }
        if (assignment.Rola.trim().length === 0 || assignment.Rola.length > 30) {
            setMessage('Pole Rola nie może być puste i musi mieć mniej niż 30 znaków.');
            return;
        }

        fetch(`http://localhost:3001/employee-project/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(assignment),
        })
            .then((response) => {
                if (!response.ok) {
                    return response.json().then((err) => {
                        throw new Error(err.message);
                    });
                }
                return response.json();
            })
            .then((data) => {
                if (data.ok) {
                    setMessage('Powiodło się!');
                    fetch(`http://localhost:3001/employee-project/${id}`)
                        .then((response) => response.json())
                        .then((data) => setAssignment(data))
                        .catch((error) => console.error(error));
                } else {
                    setMessage(data.message || 'Błąd podczas aktualizacji przypisania pracownika do projektu.');
                }
            })
            .catch((error) => {
                console.error(error);
                setMessage(error.message);
            });
    };

    return (
        <div>
            {userRole===3 || userRole===2? (
                <>
            <Link to="/Employees_Project" className="button green-button">
                Powrót do Listy Przypisań Pracowników do Projektów
            </Link>
            <h1>Modyfikuj Dane Przypisania Pracownika do Projektu</h1>
            {message && <p>{message}</p>}
            <form>
                <label>Pracownik:</label>
                <br />
                <select name="Pracownik_Id" value={assignment.Pracownik_Id} onChange={handleInputChange} required>
                    <option value="">Wybierz pracownika</option>
                    {employees.map((employee) => (
                        <option key={employee.Id} value={employee.Id}>
                            {employee.Imie} {employee.Nazwisko} {employee.Email}
                        </option>
                    ))}
                </select>
                <br />
                <label>Projekt:</label>
                <br />
                <select name="Projekt_Id" value={assignment.Projekt_Id} onChange={handleInputChange} required>
                    <option value="">Wybierz projekt</option>
                    {projects.map((project) => (
                        <option key={project.Id} value={project.Id}>
                            {project.Nazwa}
                        </option>
                    ))}
                </select>
                <br />
                <label>Rola:</label>
                <br />
                <input type="text" name="Rola" value={assignment.Rola} onChange={handleInputChange} required />
                <br />
                <button type="button" onClick={handleUpdate}>
                    Zapisz zmiany
                </button>
            </form>
                </>
            ) : (
                <p>{"Brak dostepu"}</p>
            )}
        </div>
    );
};
