import React, { useState, useEffect } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import './CSS/CreateEmployee.css';

export const ModifyEmployee = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [userRole,setUserRole]=useState('');

    const [employee, setEmployee] = useState({
        Imie: "",
        Nazwisko: "",
        Email: "",
        Data_zatrudnienia: "",
        Szef: "",
        PoziomSzefostwa: null,
        Login: "",
        Haslo: "",
        Rola: null,
    });
    const [showPassword, setShowPassword] = useState(false);
    const [bosses, setBosses] = useState([]);
    const [message, setMessage] = useState("");

    useEffect(() => {
        const token = localStorage.getItem('token');
        if (!token) {
            setMessage('Brak dostępu');
            return;
        }

        fetch('http://localhost:3001/protected-resource', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        })
            .then(response => response.json())
            .then(data => {
                if (data.Rola && data.Rola !== 3) {
                    setMessage('Brak dostępu');
                    return;
                }
                setUserRole(data.Rola)


        fetch(`http://localhost:3001/employees/${id}`)
            .then(response => response.json())
            .then(data => setEmployee(data))
            .catch(error => console.error(error));

        fetch(`http://localhost:3001/employees`)
            .then(response => response.json())
            .then(data => {
                setBosses(data.filter(boss => (parseInt(boss.Id) !== parseInt(id)) && (boss.Rola === 2|| boss.Rola===3)));
            })
            .catch(error => console.error(error));
            })
            .catch(error => console.error(error));
    }, [id]);

    const handleInputChange = (e) => {
        const { name, value } = e.target;

        setEmployee((prevEmployee) => ({
            ...prevEmployee,
            [name]: name === "PoziomSzefostwa" || name === "Rola" ? parseInt(value) : value === "null" ? null : value,
        }));
    };

    const handleUpdate = () => {
        setMessage("");
        // Validate fields
        if (!employee.Imie.trim() || !employee.Nazwisko.trim()) {
            setMessage("Imię i nazwisko nie mogą być puste");
            return;
        }

        const datePattern = /^\d{4}-\d{2}-\d{2}$/; // YYYY-MM-DD
        if (!datePattern.test(employee.Data_zatrudnienia)) {
            setMessage("Data zatrudnienia musi mieć format YYYY-MM-DD");
            return;
        }

        // Validate email format
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+/;
        if (!employee.Email.trim() || !emailPattern.test(employee.Email)) {
            setMessage('Niepoprawny format adresu e-mail.');
            return;
        }

        if (employee.Imie.length > 30 || employee.Nazwisko.length > 30 || employee.Email.length > 100) {
            setMessage("Długość Imienia, Nazwiska lub Email przekracza dopuszczalne ograniczenia");
            return;
        }

        fetch(`http://localhost:3001/employees/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(employee),
        })
            .then(response => {
                if (!response.ok) {
                    return response.json().then(err => {
                        throw new Error(err.message);
                    });
                }
                return response.json();
            })
            .then(data => {
                if (data.ok) {
                    setMessage("Powiodło się!");
                    // Aktualizacja listy szefów
                    fetch(`http://localhost:3001/employees`)
                        .then(response => response.json())
                        .then(data => {
                            setBosses(data.filter(boss => parseInt(boss.Id) !== parseInt(id)));
                        })
                        .catch(error => console.error(error));
                } else {
                    setMessage(data.message || "Błąd podczas aktualizacji pracownika.");
                }
            })
            .catch(error => {
                console.error(error);
                setMessage(error.message);
            });
    };
    const toggleShowPassword = () => {
        setShowPassword(!showPassword);
    };

    return (
        <div>
            {userRole===3 ? (
                <>
            <Link to="/employees" className="button green-button">Powrót do Listy Pracowników</Link>
            <h1>Modyfikuj Dane Pracownika</h1>
            {message && <p>{message}</p>}
            <form>
                <label>Imię:</label><br />
                <input type="text" name="Imie" value={employee.Imie} onChange={handleInputChange} required /><br />
                <label>Nazwisko:</label><br />
                <input type="text" name="Nazwisko" value={employee.Nazwisko} onChange={handleInputChange} required /><br />
                <label>Email:</label><br />
                <input type="text" name="Email" value={employee.Email} onChange={handleInputChange} required /><br />
                <label>Data zatrudnienia:</label><br />
                <input type="text" name="Data_zatrudnienia" value={employee.Data_zatrudnienia} onChange={handleInputChange} required /><br />
                <label>Szef:</label><br />
                <select name="Szef" value={employee.Szef} onChange={handleInputChange}>
                    <option value="null">Brak</option>
                    {bosses.map((boss) => (
                        <option key={boss.id} value={boss.id}>
                            {boss.Imie} {boss.Nazwisko} {boss.Email}
                        </option>
                    ))}
                </select><br />

                <label>Login:</label><br />
                <input type="text" name="Login" value={employee.Login} onChange={handleInputChange} required /><br />

                <label>Hasło:</label><br />
                <input
                    type={showPassword ? "text" : "password"}
                    name="Haslo"
                    value={employee.Haslo}
                    onChange={handleInputChange}
                    required
                />
                <button
                    type="button"
                    onClick={toggleShowPassword}
                    style={{
                        fontSize: "0.8em",
                        padding: "5px",
                        marginLeft: "5px",
                    }}
                >
                    {showPassword ? "Ukryj" : "Pokaż"}
                </button><br />
                <label>Rola:</label><br />
                <select name="Rola" value={employee.Rola} onChange={handleInputChange}>
                    <option value="1">Pracownik</option>
                    <option value="2">Szef</option>
                    <option value="3">Admin</option>
                </select><br />

                <button type="button" onClick={handleUpdate}>Zapisz zmiany</button>
            </form>
                </>
            ) : (
                <p>{"Brak Dostępu"}</p>
            )}
        </div>
    );
};
