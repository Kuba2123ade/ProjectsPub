import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import "./CSS/DetailEmployee.css";
import {useTranslation} from "react-i18next";


export const EmployeeDetails = () => {
    const { t } = useTranslation();

    const { id } = useParams();
    let IdasNumber=parseInt(id);
    const [employee, setEmployee] = useState(null);
    const [projects, setProjects] = useState([]);
    const [loading, setLoading] = useState(true);
    const [supervisor, setSupervisor] = useState(null);
    const [userRole, setUserRole] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(5);
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentProjects = projects.slice(indexOfFirstItem, indexOfLastItem);
    const paginate = (pageNumber) => {
        setCurrentPage(pageNumber);
    };

    useEffect(() => {


        const token = localStorage.getItem('token');
        if (!token) {
            return;
        }

        fetch('http://localhost:3001/protected-resource', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        })
            .then(response => response.json())
            .then(data => {
                if (data.Rola === 3 || (data.Rola === 2 || data.Rola === 1) && data.Id === IdasNumber) {
                    setUserRole(data.Rola);

                    // Fetch employee data
                    fetch(`http://localhost:3001/employees/${id}`)
                        .then(response => {
                            if (!response.ok) {
                                throw new Error('Failed to fetch employee');

                            }
                            return response.json();
                        })
                        .then(employeeData => {
                            setEmployee(employeeData);
                            setLoading(false);

                            const supervisorId = employeeData && employeeData.Szef;

                            if (supervisorId) {
                                fetch(`http://localhost:3001/employees/${supervisorId}`)
                                    .then(response => {
                                        if (!response.ok) {
                                            throw new Error('Failed to fetch supervisor');
                                        }
                                        return response.json();
                                    })
                                    .then(supervisorData => {
                                        setSupervisor(supervisorData);
                                    })
                                    .catch(error => {
                                        console.error('Failed to fetch supervisor', error);
                                    });
                            }
                        })
                        .catch(error => {
                            console.error(error.message);
                            setLoading(false);
                        });

                    fetch(`http://localhost:3001/employee/${id}/projects`)
                        .then(response => {
                            if (!response.ok) {
                                throw new Error('Failed to fetch employee projects');
                            }
                            return response.json();
                        })
                        .then(data => {
                            setProjects(data);
                        })
                        .catch(error => {
                            console.error(error.message);
                        });
                } else {
                   setUserRole('')
                }
            }
            )
            .catch(error => console.error(error) );
    }, [id]);

    return (
        <div>
            {userRole===3 || userRole===2 || userRole===1 ? (
                <>
            <nav>

                {userRole===3? (
                        <>
                <Link to="/Employees">Powrot do widoku wszystkich pracownikow</Link>
                        </>
                ) : (
                    <Link to="/">Powrot do glownej strony</Link>
                )}
            </nav>
            <h2>Szczegóły pracownika</h2>
            {loading ? (
                <p>Ładowanie danych...</p>
            ) : employee ? (
                <table>
                    <tbody>
                    <tr>
                        <td>Imie</td>
                        <td>{employee.Imie}</td>
                    </tr>
                    <tr>
                        <td>Nazwisko</td>
                        <td>{employee.Nazwisko}</td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td>{employee.Email}</td>
                    </tr>
                    <tr>
                        <td>Data Zatrudnienia</td>
                        <td>{employee.Data_zatrudnienia}</td>
                    </tr>
                    <tr>
                        <td>Login</td>
                        <td>{employee.Login}</td>
                    </tr>
                    <tr>
                        <td>Hasło</td>
                        <td>{employee.Haslo}</td>
                    </tr>
                    <tr>
                        <td>Rola</td>
                        <td>{getRoleName(employee.Rola)}</td>
                    </tr>
                    <tr>
                        <td>Szef</td>
                        <td>{supervisor ? `${supervisor.Imie} ${supervisor.Nazwisko}` : 'Brak szefa'}</td>
                    </tr>
                    </tbody>
                </table>
            ) : (
                <p>Pracownik nie został znaleziony.</p>
            )}

                    <h2>Oto Projekty z którymi jest powiązany pracownik</h2>
                    {currentProjects.length > 0 ? (
                        <>
                            <ul>
                                {currentProjects.map((project, index) => (
                                    <li key={index}>{project.Projekt_Nazwa} : {project.Rola}</li>
                                ))}
                            </ul>
                            <div className="pagination">
                                {[...Array(Math.ceil(projects.length / itemsPerPage)).keys()].map(pageNumber => (
                                    <button key={pageNumber + 1} onClick={() => paginate(pageNumber + 1)}>
                                        {pageNumber + 1}
                                    </button>
                                ))}
                            </div>
                        </>
                    ) : (
                        <p>Brak projektów dla tego pracownika.</p>
                    )}
                </>
            ) : (
                <p>Brak dostępu do danych</p>
            )}
        </div>
    );
};

const getRoleName = (role) => {
    switch (role) {
        case 1:
            return 'Pracownik';
        case 2:
            return 'Szef';
        case 3:
            return 'Admin';
        default:
            return 'Nieznana rola';
    }
};
