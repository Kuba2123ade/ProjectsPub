import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import './CSS/CreateEmployee.css';
import {useTranslation} from "react-i18next";

export const CreateEmployee = () => {
    const { t } = useTranslation();

    const [bosses, setBosses] = useState([]);
    const [message, setMessage] = useState('');
    const [statusMessage, setStatusMessage] = useState('');
    const [userRole, setUserRole] = useState('');
    const [formData, setFormData] = useState({
        Imie: '',
        Nazwisko: '',
        Email: '',
        Data_zatrudnienia: '',
        Szef: '',
        Login: '',
        Haslo: '',
        Rola: '',
        ShowPassword: false,
    });

    const handleInputChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };

    const handleShowPasswordToggle = () => {
        setFormData({
            ...formData,
            ShowPassword: !formData.ShowPassword,
        });
    };

    useEffect(() => {
        const token = localStorage.getItem('token');
        if (!token) {
            setMessage(t('Brak dostępu'));
            return;
        }

        fetch('http://localhost:3001/protected-resource', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        })
            .then(response => response.json())
            .then(data => {
                if (data.Rola && data.Rola !== 3) {
                    setMessage('Brak dostępu');
                    return;
                }
                setUserRole(data.Rola);
                fetch(`http://localhost:3001/employees`)
                    .then(response => response.json())
                    .then(data => {
                        setBosses(data.filter(employee => employee.Rola === 2||employee.Rola === 3));
                    })
                    .catch(error => console.error(error));
            })
            .catch(error => console.error(error));
    }, []);

    const handleSubmit = async () => {
        try {
            // Resetowanie komunikatów błędów
            setStatusMessage('');
            setMessage('');

            // Walidacja pól
            if (formData.Imie.trim() === '' || formData.Nazwisko.trim() === '') {
                setMessage('Imię i Nazwisko nie mogą być puste.');
                return;
            }
            if (formData.Login.trim() === '' || formData.Haslo.trim() === '') {
                setMessage('Login i Hasło nie mogą być puste.');
                return;
            }

            // Walidacja pola Email
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(formData.Email) || formData.Email.trim() === '') {
                setMessage('Nieprawidłowy format adresu e-mail.');
                return;
            }

            const datePattern = /^\d{4}-\d{2}-\d{2}$/; // YYYY-MM-DD
            if (!datePattern.test(formData.Data_zatrudnienia)) {
                setMessage("Data zatrudnienia musi mieć format YYYY-MM-DD");
                return;
            }
            if (formData.Rola === '') {
                setMessage('Rola nie może być pusta. Wybierz rolę.');
                return;
            }

            // Walidacja długości pól
            if (formData.Email.length > 100) {
                setMessage('Długość emaila przekracza dopuszczalny limit.');
                return;
            }
            if (formData.Imie.length > 30) {
                setMessage('Długość Imienia przekracza dopuszczalny limit.');
                return;
            }
            if (formData.Nazwisko.length > 30) {
                setMessage('Długość Nazwiska przekracza dopuszczalny limit.');
                return;
            }
            if (formData.Login > 30) {
                setMessage('Długość jednego z pól przekracza dopuszczalny limit.');
                return;
            }
            if (formData.Haslo > 30) {
                setMessage('Długość hasła przekracza dopuszczalny limit.');
                return;
            }

            const response = await fetch('http://localhost:3001/employees', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData),
            });

            if (response.ok) {
                setBosses([...bosses, formData]);

                setFormData({
                    Imie: '',
                    Nazwisko: '',
                    Email: '',
                    Data_zatrudnienia: '',
                    Szef: '',
                    Login: '',
                    Haslo: '',
                    Rola: '',
                    ShowPassword: false,
                });

                const result = await response.json();
                console.log('Employee added successfully with ID:', result.id);
                setStatusMessage('Pracownik dodany pomyślnie.');
            } else {
                const errorResponse = await response.json();
                if (errorResponse.error === 'Employee with the same name and email already exists') {
                    console.error('Employee with the same name and email already exists');
                    setStatusMessage('Użytkownik o podanych danych już istnieje w bazie danych.');
                } else {
                    console.error('Failed to add employee');
                    setStatusMessage('Błąd podczas dodawania pracownika.');
                }
            }
        } catch (error) {
            console.error('Error adding employee:', error);
            setStatusMessage('Wystąpił błąd podczas komunikacji z serwerem.');
        }
    };

    return (
        <div>
            {userRole === 3 ? (
                <>
                    <nav>
                        <Link to="/Employees">{t("Back to the main view of all employees")}</Link>
                    </nav>
                    <h2>{t("Employee Creation Form")}</h2>
                    <div>
                        <label htmlFor="Imie">{t("Name")}:</label><br />
                        <input type="text" id="Imie" name="Imie" value={formData.Imie} onChange={handleInputChange} /><br />
                        <label htmlFor="Nazwisko">{t("Surname")}:</label><br />
                        <input type="text" id="Nazwisko" name="Nazwisko" value={formData.Nazwisko} onChange={handleInputChange} /><br />
                        <label htmlFor="Email">{t("Email")}:</label><br />
                        <input type="text" id="Email" name="Email" value={formData.Email} onChange={handleInputChange} /><br />
                        <label htmlFor="Data_zatrudnienia">{t("Hiring Date")}:</label><br />
                        <input type="date" id="Data_zatrudnienia" name="Data_zatrudnienia" value={formData.Data_zatrudnienia} onChange={handleInputChange} /><br />
                        <label>Szef:</label><br />
                        <select name="Szef" onChange={handleInputChange}>
                            <option value="null">Brak</option>
                            {bosses.map((boss) => (
                                <option key={boss.id} value={boss.id}>
                                    {boss.Imie} {boss.Nazwisko} {boss.Email}
                                </option>
                            ))}
                        </select><br />
                        <label htmlFor="Login">{t("Login")}</label><br />
                        <input type="text" id="Login" name="Login" value={formData.Login} onChange={handleInputChange} /><br />

                        <label>{t("Password")}:</label><br />
                        <input
                            type={formData.ShowPassword ? "text" : "password"}
                            id="Haslo"
                            name="Haslo"
                            value={formData.Haslo}
                            onChange={handleInputChange}
                        />
                        <button
                            type="button"
                            onClick={handleShowPasswordToggle}
                            style={{
                                fontSize: "0.8em",
                                padding: "5px",
                                marginLeft: "5px",
                            }}
                        >
                            {formData.ShowPassword ? t("Hide Password") : t("Show Password")}
                        </button><br />

                        <label htmlFor="Rola">{t("Role")}:</label><br />
                        <select
                            name="Rola"
                            onChange={handleInputChange}
                            value={formData.Rola}
                        >
                            <option value="">{t("Choose role")}</option>
                            <option value="1">{t("Employee")}</option>
                            <option value="2">{t("Boss")}</option>
                            <option value="3">{t("Admin")}</option>
                        </select><br />

                        <button onClick={handleSubmit}>{t("Add Employee")}</button>
                        {message && <p style={{ color: 'red' }}>{t(message)}</p>}
                        {statusMessage && <p style={{ color: 'green' }}>{t(statusMessage)}</p>}
                    </div>
                </>
            ) : (
                <p>{t("No access")}</p>
            )}
        </div>
    );

};
