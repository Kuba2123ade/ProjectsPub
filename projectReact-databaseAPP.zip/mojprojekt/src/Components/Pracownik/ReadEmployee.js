import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import './CSS/ReadEmployee.css';

export const Employees = () => {
    const [employees, setEmployees] = useState([]);
    const [errorMessage, setErrorMessage] = useState('');
    const [userId, setuserId] = useState('');
    const navigate = useNavigate();
    const [userRole,setUserRole]=useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(5);
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = employees.slice(indexOfFirstItem, indexOfLastItem);

    const paginate = (pageNumber) => {
        setCurrentPage(pageNumber);
    };
    useEffect(() => {
        const token = localStorage.getItem('token');
        if (!token) {
            setErrorMessage('Brak dostępu');
            return;
        }

        fetch('http://localhost:3001/protected-resource', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        })
            .then(response => response.json())
            .then(data => {
                if (data.Rola && data.Rola !== 3) {
                    setErrorMessage("brak dostepu");
                    return;
                }
                setuserId(data.Id)
                setUserRole(data.Rola); // Zaktualizuj to
                fetch('http://localhost:3001/employees')
                    .then(response => response.json())
                    .then(data => setEmployees(data))
                    .catch(error => console.error(error));
            })
            .catch(error => console.error(error));
    }, []);


    const handleDelete = (employeeId) => {
        setErrorMessage('');
        fetch(`http://localhost:3001/employees/${employeeId}`, {
            method: 'DELETE',
        })
            .then(response => response.json())
            .then(data => {
                if (data.message === 'Employee deleted successfully') {
                    if(userId===employeeId) {
                        localStorage.removeItem('token')
                        navigate("/");
                    }
                    setEmployees(prevEmployees => prevEmployees.filter(employee => employee.Id !== employeeId));
                    console.log('Employee deleted successfully');
                } else {
                    console.error(data.message);
                    setErrorMessage(data.message);
                }
            })
            .catch(error => console.error(error));
    };

    const handleModify = (employeeId) => {
        navigate(`/ModifyEmployee/${employeeId}`);
    };

    return (
        <div>

             <Link to="/" className="button green-button">Powrót do Strony Głównej</Link>
            {userRole === 3 ? (
                <>
                    <Link to="/CreateEmployee" className="button black-button">Dodaj Pracownika</Link>
                    <h1>Lista Pracowników</h1>

                    {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}

                    {currentItems.length > 0 ? (
                        <ul>
                            {currentItems.map((employee) => (
                                <li key={employee.Id}>
                                    <table className="custom-table">
                                        <tbody>

                                    <Link to={`/EmployeeDetails/${employee.Id}`} className="employee-link">
                                        <tr>
                                        {'Imie: '+employee.Imie}
                                        </tr>
                                        <tr>
                                            {' Nazwisko: '+employee.Nazwisko}
                                        </tr>
                                        <tr>
                                        {'Email: '+employee.Email}
                                        </tr>
                                    </Link>
                                        </tbody>
                                    </table>
                                    <div>
                                        <button onClick={() => handleModify(employee.Id)}>Modyfikuj</button>
                                        <button onClick={() => handleDelete(employee.Id)}>Usuń</button>
                                    </div>
                                </li>
                            ))}
                        </ul>
                    ) : (
                        <p>Brak pracowników</p>
                    )}

                    <div className="pagination">
                        {[...Array(Math.ceil(employees.length / itemsPerPage)).keys()].map(pageNumber => (
                            <button key={pageNumber + 1} onClick={() => paginate(pageNumber + 1)}>
                                {pageNumber + 1}
                            </button>
                        ))}
                    </div>
                </>
            ) : (
                <p>{errorMessage}</p>
            )}
        </div>
    );
};
