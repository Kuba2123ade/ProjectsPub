import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './MyHomePage.css';
import { useTranslation } from 'react-i18next';
import i18n from './i18n';

export const MyHomePage = () => {
    const { t } = useTranslation();
    const [currentLanguage, setCurrentLanguage] = useState('pl');
    const changeLanguage = (lng) => {
        i18n.changeLanguage(lng);
        setCurrentLanguage(lng);
        localStorage.setItem('language', lng);
    };
    const [login, setLogin] = useState('');
    const [password, setPassword] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [employeeId, setEmployeeId] = useState(localStorage.getItem('employeeId') || '');

    useEffect(() => {
        const savedLanguage = localStorage.getItem('language');
        if (savedLanguage) {
            i18n.changeLanguage(savedLanguage);
        }
        const token = localStorage.getItem('token');
        if (token) {
            fetch('http://localhost:3001/protected-resource', {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`,
                },
            })
                .then(response => response.json())
                .then(data => {
                    if (data.id) {
                        setErrorMessage(data.id)
                        setEmployeeId(data.id);
                        localStorage.setItem('employeeId', data.id);
                    }
                })
                .catch(error => console.error(error));
        }
        setIsLoggedIn(!!token);
    }, []);

    const handleLogin = () => {
        if (!login || !password) {
            setErrorMessage(t('hasło i login są wymagane.'));
            return;
        }

        setErrorMessage('');

        fetch('http://localhost:3001/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ login, haslo: password }),
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    localStorage.setItem('token', data.token);
                    const token = localStorage.getItem('token');
                    if (!token) {
                        return;
                    }

                    fetch('http://localhost:3001/protected-resource', {
                        headers: {
                            'Authorization': `Bearer ${token}`,
                        },
                    })
                        .then(response => response.json())
                        .then(data => {
                            if (!data.Id) {
                                setErrorMessage(t('Unauthorized access to your details'));
                                return;
                            }
                            setEmployeeId(data.Id);
                            localStorage.setItem('employeeId', data.Id);
                            setIsLoggedIn(true);
                            setErrorMessage(t('zalogowano!'))
                        })
                        .catch(error => console.error(error));

                } else {
                    setErrorMessage(data.error || t('Login error'));
                }
            })
            .catch(error => console.error(error));
    };

    const handleLogout = () => {
        localStorage.removeItem('token');
        localStorage.removeItem('employeeId');
        setIsLoggedIn(false);
        setErrorMessage('');
        setEmployeeId('');
    };

    return (
        <div className="container">
            <button onClick={() => changeLanguage(currentLanguage === 'en' ? 'pl' : 'en')}>
                {currentLanguage.toUpperCase()}
            </button>
            <h1 className="title" style={{ fontSize: '1.5em' }}>{t('Welcome')}</h1>
            <div className="login-form">
                {errorMessage && <p style={{ color: 'red', fontSize: '0.8em' }}>{errorMessage}</p>}
                <br />
                <label>
                    {t('Login')}:
                    <input type="text" value={login} onChange={(e) => setLogin(e.target.value)} />
                </label>
                <br />
                <label>
                    {t('Password')}:
                    <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
                </label>
                <button onClick={handleLogin} style={{ fontSize: '1em' }}>{t('Login')}</button>
                {isLoggedIn && <button onClick={handleLogout} style={{ fontSize: '1em' }}>{t('Logout')}</button>}
            </div>

            <div className="header">
                <p className="description" style={{ fontSize: '1em' }}>{t('Choose')}</p>
                <table className="links-table">
                    <tbody>
                    <tr>
                        <td><Link to="/Employees">{t('Employees Management Page')}</Link></td>
                        <td><Link to="/Projects">{t('Projects Management Page')}</Link></td>
                    </tr>
                    <tr>
                        <td><Link to="/Employees_Project">{t('Page for managing connections between employees and projects')}</Link></td>
                        {isLoggedIn && employeeId && (
                            <td><Link to={`/EmployeeDetails/${employeeId}`}>{t('Employee Details')}</Link></td>
                        )}
                    </tr>
                    </tbody>
                </table>
            </div>
            <div className="image-container">
                <img src="https://www.applauz.me/hubfs/blog_academy_4-core-management-styles-and-when-to-use-them_fimage-01.jpg" alt="Obrazek" />
            </div>
        </div>
    );
};
