import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import './CSS/ReadProject.css'

export const Projects = () => {
    const [projects, setProjects] = useState([]);
    const navigate = useNavigate();
    const [userRole, setUserRole] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(5);

    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentProjects = projects.slice(indexOfFirstItem, indexOfLastItem);

    const paginate = (pageNumber) => {
        setCurrentPage(pageNumber);
    };

    useEffect(() => {
        const token = localStorage.getItem('token');
        if (!token) {
            return;
        }

        fetch('http://localhost:3001/protected-resource', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        })
            .then(response => response.json())
            .then(data => {
                if (data.Rola && data.Rola !== 3) {
                    return;
                }
                setUserRole(data.Rola);
                fetch('http://localhost:3001/projects')
                    .then(response => response.json())
                    .then(data => setProjects(data))
                    .catch(error => console.error(error));
            })
            .catch(error => console.error(error));
    }, []);

    const handleDelete = (projectId) => {
        fetch(`http://localhost:3001/projects/${projectId}`, {
            method: 'DELETE',
        })
            .then(response => response.json())
            .then(data => {
                console.log('Project deleted successfully');
                if (data.message === 'Project deleted successfully') {
                    setProjects(prevProjects => prevProjects.filter(project => project.Id !== projectId));
                }
            })
            .catch(error => console.error(error));
    };

    const handleModify = (projectId) => {
        navigate(`/ModifyProject/${projectId}`);
    };

    return (
        <div>

            <Link to="/" className="button green-button">Powrót do Strony Głównej</Link>
            {userRole===3 ? (
                <>
                    <Link to="/CreateProject" className="button black-button">Dodaj Projekt</Link>
                    <h1>Lista Projektów</h1>
                    {currentProjects.length > 0 ? (
                        <>
                            <ul>
                                {currentProjects.map((project) => (
                                    <li key={project.Id}>
                                        <table className="ProjectsTable">
                                            <tbody>
                                            <tr>
                                                <td className="project-link">
                                                    <Link to={`/ProjectDetails/${project.Id}`}>
                                                        <div>
                                                            <span style={{ textAlign: 'left' }}>Nazwa Projektu:</span>
                                                            <span style={{ textAlign: 'left' }}>{project.Nazwa}</span>
                                                        </div>
                                                    </Link>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td className="project-link">
                                                    <Link to={`/ProjectDetails/${project.Id}`}>
                                                        <div>
                                                            <span style={{ textAlign: 'left' }}>Początek Projektu:</span>
                                                            <span style={{ textAlign: 'left' }}>{project.Poczatek_Proj}</span>
                                                        </div>
                                                    </Link>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td className="project-link">
                                                    <Link to={`/ProjectDetails/${project.Id}`}>
                                                        <div>
                                                            <span style={{ textAlign: 'left' }}>Koniec Projektu:</span>
                                                            <span style={{ textAlign: 'left' }}>{project.Koniec_Projektu}</span>
                                                        </div>
                                                    </Link>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>

                                        <div>
                                            <button onClick={() => handleModify(project.Id)}>Modyfikuj</button>
                                            <button onClick={() => handleDelete(project.Id)}>Usuń</button>
                                        </div>
                                    </li>
                                ))}
                            </ul>



                            <div className="pagination">
                                {[...Array(Math.ceil(projects.length / itemsPerPage)).keys()].map(pageNumber => (
                                    <button key={pageNumber + 1} onClick={() => paginate(pageNumber + 1)}>
                                        {pageNumber + 1}
                                    </button>
                                ))}
                            </div>
                        </>
                    ) : (
                        <p>Brak projektów</p>
                    )}
                </>
            ) : (
                <p>{"Brak dostepu"}</p>
            )}
        </div>
    );
}
