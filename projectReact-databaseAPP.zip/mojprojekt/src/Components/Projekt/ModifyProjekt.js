import React, { useState, useEffect } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import './CSS/CreateProject.css';

export const ModifyProject = () => {
    const { id } = useParams();
    const [userRole, setUserRole] = useState('');

    const [project, setProject] = useState({
        Nazwa: "",
        Poczatek_Proj: "",
        Koniec_Projektu: "",
        Szef_Id: null
    });

    const [bosses, setBosses] = useState([]);
    const [message, setMessage] = useState("");

    useEffect(() => {
        const token = localStorage.getItem('token');
        if (!token) {
            setMessage('Brak dostępu');
            return;
        }

        fetch('http://localhost:3001/protected-resource', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        })
            .then(response => response.json())
            .then(data => {
                if (data.Rola && data.Rola !== 3) {
                    setMessage('Brak dostępu');
                    return;
                }
                setUserRole(data.Rola);
        fetch(`http://localhost:3001/projects/${id}`)
            .then(response => response.json())
            .then(data => setProject(data))
            .catch(error => console.error(error));

        fetch(`http://localhost:3001/employees`)
            .then(response => response.json())
            .then(data => {
                setBosses(data.filter(employee => employee.Rola === 2||employee.Rola===3));
            })
            .catch(error => console.error(error));
            })
            .catch(error => console.error(error));
    }, []);
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setProject({
            ...project,
            [name]: value === "null" ? null : value
        });
    };

    const handleUpdate = () => {
        setMessage("");
        // Validate fields
        if (!project.Nazwa.trim()) {
            setMessage("Nazwa projektu nie może być pusta");
            return;
        }

        const datePattern = /^\d{4}-\d{2}-\d{2}$/;
        // Validation for project dates
        if (project.Koniec_Projektu && !project.Poczatek_Proj) {
            setMessage("Nie można ustalać końca projektu bez jego początku");
            return;
        }
        if (project.Poczatek_Proj) {
            if (!datePattern.test(project.Poczatek_Proj)) {
                setMessage("Data początkowa musi mieć format YYYY-MM-DD");
                return;
            }
            if (project.Koniec_Projektu) {
                if (!datePattern.test(project.Koniec_Projektu)) {
                    setMessage("Data zakończenia musi mieć format YYYY-MM-DD");
                    return;
                }
                const startDate = new Date(project.Poczatek_Proj);
                const endDate = new Date(project.Koniec_Projektu);

                const minimumEndDate = new Date(startDate);
                minimumEndDate.setMonth(startDate.getMonth() + 1);
                if (endDate < minimumEndDate) {
                    setMessage("Data zakończenia projektu musi być co najmniej miesiąc później niż jego początek");
                    return;
                }
            }
        }

        fetch(`http://localhost:3001/projects/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(project),
        })
            .then(response => {
                if (!response.ok) {
                    return response.json().then(err => {
                        throw new Error(err.message);
                    });
                }
                return response.json();
            })
            .then(data => {
                if (data.ok) {
                    setMessage("Powiodło się!");
                } else {
                    setMessage(data.message || "Błąd podczas aktualizacji projektu.");
                }
            })
            .catch(error => {
                console.error(error);
                setMessage(error.message);
            });
    };

    return (
        <div>
            {userRole===3 ? (
                <>
            <Link to="/projects" className="button green-button">Powrót do Listy Projektów</Link>
            <h1>Modyfikuj Dane Projektu</h1>
            {message && <p>{message}</p>}
            <form>
                <label>Nazwa projektu:</label><br />
                <input type="text" name="Nazwa" value={project.Nazwa} onChange={handleInputChange} required /><br />
                <label>Początek projektu:</label><br />
                <input type="date" name="Poczatek_Proj" value={project.Poczatek_Proj} onChange={handleInputChange} required /><br />
                <label>Koniec projektu:</label><br />
                <input type="date" name="Koniec_Projektu" value={project.Koniec_Projektu} onChange={handleInputChange} required /><br />
                <label>Szef projektu:</label><br />
                <select name="Szef_Id" value={project.Szef_Id} onChange={handleInputChange}>
                    <option value="null">Brak</option>
                    {bosses.map((boss) => (
                        <option key={boss.Id} value={boss.Id}>
                            {boss.Imie} {boss.Nazwisko} {boss.Email}
                        </option>
                    ))}
                </select><br />
                <button type="button" onClick={handleUpdate}>Zapisz zmiany</button>
            </form>
                </>
            ) : (
                <p>{"Brak dostepu"}</p>
            )}
        </div>
    );
};
