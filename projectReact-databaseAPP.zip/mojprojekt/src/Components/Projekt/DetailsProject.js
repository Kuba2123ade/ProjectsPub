import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import "./CSS/DetailProject.css";

export const ProjectDetails = () => {
    const { id } = useParams();
    const [project, setProject] = useState(null);
    const [employees, setEmployees] = useState([]);
    const [loading, setLoading] = useState(true);
    const [userRole, setUserRole] = useState('');

    const [currentPage, setCurrentPage] = useState(1);
    const [employeesPerPage] = useState(5);




    useEffect(() => {

        const token = localStorage.getItem('token');
        if (!token) {
            return;
        }

        fetch('http://localhost:3001/protected-resource', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        })
            .then(response => response.json())
            .then(data => {
                if (data.Rola && data.Rola !== 3) {
                    return;
                }
                setUserRole(data.Rola);
        // Fetch project data
        fetch(`http://localhost:3001/projects/${id}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Failed to fetch project');
                }
                return response.json();
            })
            .then(data => {
                setProject(data);
                setLoading(false);

                // Fetch employees associated with the project
                fetch(`http://localhost:3001/projects/${id}/employees`)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Failed to fetch project employees');
                        }
                        return response.json();
                    })
                    .then(employeesData => {
                        console.log("Project Employees Data: ", employeesData);
                        setEmployees(employeesData);
                    })
                    .catch(error => {
                        console.error('Failed to fetch project employees', error);
                    });
            })
            .catch(error => {
                console.error(error.message);
                setLoading(false);
            });
            })
            .catch(error => console.error(error));
    }, []);

    const indexOfLastEmployee = currentPage * employeesPerPage;
    const indexOfFirstEmployee = indexOfLastEmployee - employeesPerPage;
    const currentEmployees = employees.slice(indexOfFirstEmployee, indexOfLastEmployee);
    const paginate = (pageNumber) => setCurrentPage(pageNumber);

    return (
        <div className="container">
            {userRole === 3 ? (
                <>
                    <nav className="navbar">
                        <Link to="/Projects" className="nav-link">Powrót do widoku wszystkich projektów</Link>
                    </nav>
                    <div className="project-details">
                        <h2>Szczegóły projektu</h2>
                        {loading ? (
                            <p>Ładowanie danych...</p>
                        ) : project ? (
                            <table className="project-table">
                                <tbody>
                                <tr>
                                    <td>Nazwa</td>
                                    <td>{project.Nazwa}</td>
                                </tr>
                                <tr>
                                    <td>Początek Projektu</td>
                                    <td>{project.Poczatek_Proj}</td>
                                </tr>
                                <tr>
                                    <td>Koniec Projektu</td>
                                    <td>{project.Koniec_Projektu}</td>
                                </tr>
                                <tr>
                                    <td>Szef Projektu</td>
                                    <td>
                                        {project.Szef_Id ? (
                                            <span>
                                                    {project.Szef_Imie} {project.Szef_Nazwisko} ({project.Szef_Email})
                                                </span>
                                        ) : (
                                            'Brak szefa projektu'
                                        )}
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        ) : (
                            <p>Projekt nie został znaleziony.</p>
                        )}
                    </div>

                    <div className="employees-section">
                        <h2>Pracownicy powiązani z projektem</h2>
                        {currentEmployees.length > 0 ? (
                            <>
                                <ul className="employee-list">
                                    {currentEmployees.map((employee, index) => (
                                        <li key={index}>{employee.Imie} {employee.Nazwisko} : {employee.Rola}</li>
                                    ))}
                                </ul>

                                <div className="pagination">
                                    {Array.from({ length: Math.ceil(employees.length / employeesPerPage) }, (_, index) => (
                                        <button style={{background: "#007bff"}} key={index + 1} onClick={() => paginate(index + 1)}>
                                            {index + 1}
                                        </button>
                                    ))}
                                </div>
                            </>
                        ) : (
                            <p>Brak pracowników powiązanych z projektem.</p>
                        )}
                    </div>
                </>
            ) : (
                <p>{"Brak dostępu"}</p>
            )}
        </div>
    );
};
