import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import './CSS/CreateProject.css';

export const CreateProject = () => {
    const [managers, setManagers] = useState([]);
    const [message, setMessage] = useState('');
    const [statusMessage, setStatusMessage] = useState('');

    const [userRole, setUserRole] = useState('');
    const [formData, setFormData] = useState({
        Nazwa: '',
        Poczatek_Proj: null,
        Koniec_Projektu: null,
        Szef_Id: '',
    });

    const handleInputChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };

    useEffect(() => {
        const token = localStorage.getItem('token');
        if (!token) {
            setMessage('Brak dostępu');
            return;
        }

        fetch('http://localhost:3001/protected-resource', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        })
            .then(response => response.json())
            .then(data => {
                if (data.Rola && data.Rola !== 3) {
                    setMessage('Brak dostępu');
                    return;
                }
                setUserRole(data.Rola);
        fetch(`http://localhost:3001/employees`)
            .then(response => response.json())
            .then(data => {
                setManagers(data.filter(employee => employee.Rola === 2||employee.Rola === 3));
            })
            .catch(error => console.error(error));
            })
            .catch(error => console.error(error));
    }, []);

    const handleSubmit = async () => {
        try {
            setStatusMessage('');
            setMessage('');


            if (formData.Nazwa.trim().length === 0) {
                setMessage('Pole Nazwa nie może być puste.');
                return;
            }
            if (formData.Nazwa.length > 30) {
                setMessage('Pole Nazwa nie może przekraczać 30 znaków.');
                return;
            }
            const datePattern = /^\d{4}-\d{2}-\d{2}$/;


            if (formData.Koniec_Projektu && !formData.Poczatek_Proj) {
                setMessage("Nie można ustalać końca projektu bez jego początku");
                return;
            }
            if (formData.Poczatek_Proj) {
                if (!datePattern.test(formData.Poczatek_Proj)) {
                    setMessage("Data początkowa musi mieć format YYYY-MM-DD");
                    return;
                }
                if (formData.Koniec_Projektu) {
                    if (!datePattern.test(formData.Koniec_Projektu)) {
                        setMessage("Data zakończenia musi mieć format YYYY-MM-DD");
                        return;
                    }
                    const startDate = new Date(formData.Poczatek_Proj);
                    const endDate = new Date(formData.Koniec_Projektu);

                    const minimumEndDate = new Date(startDate);
                    minimumEndDate.setMonth(startDate.getMonth() + 1);
                    if (endDate < minimumEndDate) {
                        setMessage("Data zakończenia projektu musi być co najmniej miesiąc później niż jego początek");
                        return;
                    }
                }
            }

            const response = await fetch('http://localhost:3001/projects', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData),
            });

            if (response.ok) {
                const updatedManagers = await fetch(`http://localhost:3001/employees`)
                    .then(response => response.json())
                    .then(data =>{
                        setManagers(data.filter(employee => (employee.Rola === 2)));

                    })
                    .catch(error => console.error(error));

                setFormData({
                    Nazwa: '',
                    Poczatek_Proj: null,
                    Koniec_Projektu: null,
                    Szef_Id: '',
                });

                const result = await response.json();
                console.log('Project added successfully with ID:', result.id);
                setStatusMessage('Projekt dodany pomyślnie.');
            } else {
                const errorResponse = await response.json();
                if (errorResponse.error === 'Project with the same name already exists') {
                    console.error('Project with the same name already exists');
                    setStatusMessage('Projekt o podanej nazwie już istnieje w bazie danych.');
                } else {
                    console.error('Failed to add project');
                    setStatusMessage('Błąd podczas dodawania projektu.');
                }
            }
        } catch (error) {
            console.error('Error adding project:', error);
            setStatusMessage('Wystąpił błąd podczas komunikacji z serwerem.');
        }
    };

    return (
        <div>
            {userRole===3 ? (
                <>
            <nav>
                <Link to="/Projects">Powrót do widoku wszystkich projektów</Link>
            </nav>
            <h2>Formularz dodawania projektu</h2>
            <div>
                <label htmlFor="Nazwa">Nazwa:</label><br />
                <input type="text" id="Nazwa" name="Nazwa" value={formData.Nazwa} onChange={handleInputChange} /><br />
                <label htmlFor="Poczatek_Proj">Początek projektu:</label><br />
                <input type="date" id="Poczatek_Proj" name="Poczatek_Proj" value={formData.Poczatek_Proj || ''} onChange={handleInputChange} /><br />
                <label htmlFor="Koniec_Projektu">Koniec projektu:</label><br />
                <input type="date" id="Koniec_Projektu" name="Koniec_Projektu" value={formData.Koniec_Projektu || ''} onChange={handleInputChange} /><br />
                <label>Szef:</label><br />
                <select name="Szef_Id" onChange={handleInputChange}>
                    <option value="">Brak</option>
                    {managers.map((manager) => (
                        <option key={manager.id} value={manager.id}>
                            {manager.Imie} {manager.Nazwisko} {manager.Email}
                        </option>
                    ))}
                </select><br />
                <button onClick={handleSubmit}>Dodaj projekt</button>
                {message && <p style={{ color: 'red' }}>{message}</p>}
                {statusMessage && <p style={{ color: 'green' }}>{statusMessage}</p>}
            </div>
                </>
            ) : (
                <p>{"Brak dostepu"}</p>
            )}
        </div>
    );
};
