import React, { useCallback, useEffect, useState } from 'react';
import { Route, BrowserRouter as Router, Routes } from 'react-router-dom';
import { Employees } from './Components/Pracownik/ReadEmployee';
import { ModifyEmployee } from './Components/Pracownik/ModifyEmployee';
import { CreateEmployee } from "./Components/Pracownik/CreateEmployee";
import { EmployeeDetails } from "./Components/Pracownik/DetailsEmployee";
import { CreateProject } from "./Components/Projekt/CreateProject";
import {Projects} from "./Components/Projekt/ReadProject";
import {ModifyProject} from "./Components/Projekt/ModifyProjekt";
import {ProjectDetails} from "./Components/Projekt/DetailsProject";
import { Employees_Project } from "./Components/Pracownik-Projekt/ReadEmployee_Project";
import {CreateEmployee_Project} from "./Components/Pracownik-Projekt/CreateEmployee_Project";
import {EmployeeProjectDetails} from "./Components/Pracownik-Projekt/DetailsEmployee_Project";
import { UpdateEmployeeProject} from "./Components/Pracownik-Projekt/ModifyEmployee_Project";
import { MyHomePage} from "./Components/mainPage";
const App = () => {
  useEffect(() => {
    localStorage.clear();
  }, []);
  return (
      <Router>
        <Routes>
          <Route path="/Employees" element={<Employees />} />
          <Route path="/ModifyEmployee/:id" element={<ModifyEmployee />} />
          <Route path="/CreateEmployee" element={<CreateEmployee />} />
          <Route path="/EmployeeDetails/:id" element={<EmployeeDetails />} />
          <Route path="/Employees_Project" element={<Employees_Project />} />
          <Route path="/EmployeeProjectDetails/:id" element={<EmployeeProjectDetails />} />
          <Route path="/CreateEmployees_Project" element={<CreateEmployee_Project />} />
          <Route path="/UpdateEmployee_Project/:id" element={<UpdateEmployeeProject />} />
          <Route path="/Projects" element={<Projects />} />
          <Route path="/ProjectDetails/:id" element={<ProjectDetails />} />
          <Route path="/CreateProject" element={<CreateProject />} />
          <Route path="/ModifyProject/:id" element={<ModifyProject />} />
          <Route path="/" element={<MyHomePage />} />
        </Routes>
      </Router>
  );
};

export default App;
