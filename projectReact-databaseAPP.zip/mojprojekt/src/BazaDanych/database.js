const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

const dbDir = path.resolve(__dirname);
const dbPath = path.join(dbDir, 'mydatabase.db');
if (!fs.existsSync(dbDir)){
    fs.mkdirSync(dbDir);
}

const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Database connection error:', err.message);
    } else {
        console.log('Connected to the database');
    }
});

const dropTables = () => {
    const dropScript = `
        DROP TABLE IF EXISTS Pracownik_Projekt;
        DROP TABLE IF EXISTS Projekt;
        DROP TABLE IF EXISTS Pracownik;
    `;

    db.exec(dropScript, (err) => {
        if (err) {
            console.error('Error dropping tables:', err.message);
        } else {
            console.log('Tables dropped successfully');
        }
    });
};

const createTables = () => {
    const sqlScript = `
        -- Table: Pracownik
        CREATE TABLE IF NOT EXISTS Pracownik (
            Id INTEGER PRIMARY KEY NOT NULL,
            Imie VARCHAR(30) NOT NULL,
            Email VARCHAR(100) NOT NULL,
            Nazwisko VARCHAR(30) NOT NULL,
            Data_zatrudnienia DATE NOT NULL,
            Szef INTEGER NULL,
            Login VARCHAR(30) NOT NULL,
            Haslo VARCHAR(30) NOT NULL,
            Rola INTEGER NOT NULL,
            CONSTRAINT Pracownik_Pracownik FOREIGN KEY (Szef) REFERENCES Pracownik (Id)
        );

        -- Table: Projekt
        CREATE TABLE IF NOT EXISTS Projekt (
            Id INTEGER PRIMARY KEY NOT NULL,
            Nazwa VARCHAR(30) NOT NULL,
            Poczatek_Proj DATE NULL,
            Koniec_Projektu DATE NULL,
            Szef_Id INTEGER NULL,
            CONSTRAINT Projekt_Pracownik FOREIGN KEY (Szef_Id) REFERENCES Pracownik (Id)
        );

        -- Table: Pracownik_Projekt
        CREATE TABLE IF NOT EXISTS Pracownik_Projekt (
            Pracownik_Id INTEGER NOT NULL,
            Projekt_Id INTEGER NOT NULL,
            Id INTEGER PRIMARY KEY NOT NULL,
            Rola VARCHAR(30) NOT NULL,
            CONSTRAINT Pracownik_Projekt_Pracownik FOREIGN KEY (Pracownik_Id) REFERENCES Pracownik (Id),
            CONSTRAINT Pracownik_Projekt_Projekt FOREIGN KEY (Projekt_Id) REFERENCES Projekt (Id)
        );
    `;

    const statements = sqlScript.split(';');

    statements.forEach((statement) => {
        if (statement.trim() !== '') {
            db.exec(statement, (err) => {
                if (err) {
                    console.error('Error executing statement:', err.message);
                } else {
                    console.log('Statement executed successfully');
                }
            });
        }
    });
};
dropTables()
createTables();




const seedDatabase = () => {
    const seedScript = `
        -- Insert records into Pracownik table
        INSERT INTO Pracownik (Id, Imie, Nazwisko, Data_zatrudnienia, Szef, Email, Login, Haslo, Rola)
        VALUES (1, 'Jan', 'Kowalski', '2024-01-01', NULL, 'jan.kowalski@example.com', 'jan_login', 'jan_haslo', 2),
               (2, 'Anna', 'Nowak', '2023-11-15', 1, 'anna.nowak@example.com', 'anna_login', 'anna_haslo', 1),
               (3, 'Piotr', 'Wiśniewski', '2023-09-20', 1, 'piotr.wisniewski@example.com', 'piotr_login', 'piotr_haslo', 1),
               (4, 'Mateusz', 'Dąbrowski', '2023-10-10', 5, 'mateusz.dabrowski@example.com', 'mateusz_login', 'mateusz_haslo', 2),
               (5, 'Katarzyna', 'Lewandowska', '2023-12-05', 7, 'katarzyna.lewandowska@example.com', 'katarzyna_login', 'katarzyna_haslo', 2),
               (6, 'Michał', 'Kozłowski', '2024-02-15', 5, 'michal.kozlowski@example.com', 'michal_login', 'michal_haslo', 2),
               (7, 'Admin', 'Adminowski', '2024-01-14', NULL, 'admin@example.com', 'admin_login', 'admin_haslo', 3);

        -- Insert records into Projekt table
        INSERT INTO Projekt (Id, Nazwa, Poczatek_Proj, Koniec_Projektu, Szef_Id)
        VALUES (1, 'Projekt1', '2024-02-01', '2024-12-31', 1),
               (2, 'Projekt2', '2024-03-15', '2024-11-30', 2),
               (3, 'Projekt3', '2024-05-10', '2024-10-15', 3),
               (4, 'Projekt4', '2024-06-01', '2024-09-30', 1),
               (5, 'Projekt5', '2024-04-15', '2024-08-31', 3),
               (6, 'Projekt6', '2024-07-10', '2024-12-15', 2);

        -- Insert records into Pracownik_Projekt table
        INSERT INTO Pracownik_Projekt (Pracownik_Id, Projekt_Id, Id, Rola)
        VALUES (1, 1, 1, 'Manager'),
               (2, 2, 2, 'Developer'),
               (3, 3, 3, 'Tester'),
               (4, 4, 4, 'Developer'),
               (5, 5, 5, 'Developer'),
               (6, 6, 6, 'Developer');
    `;

    const statements = seedScript.split(';');

    statements.forEach((statement) => {
        if (statement.trim() !== '') {
            db.exec(statement, (err) => {
                if (err) {
                    console.error('Error executing statement:', err.message);
                } else {
                    console.log('Statement executed successfully');
                }
            });
        }
    });
};

seedDatabase();

const displayTables = () => {
    const tables = ['Pracownik', 'Projekt', 'Pracownik_Projekt'];

    tables.forEach((table) => {
        console.log(`\nContents of ${table}:`);

        db.all(`SELECT * FROM ${table}`, [], (err, rows) => {
            if (err) {
                console.error('Error fetching rows:', err.message);
            } else {
                console.table(rows);
            }
        });
    });
};

displayTables();



module.exports = db;
