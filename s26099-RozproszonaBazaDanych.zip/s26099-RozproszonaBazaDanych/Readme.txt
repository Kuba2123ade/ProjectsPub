WSTĘP
Rozproszona baza daynych ma za zadanie zawierać na wielu serwerach informacje które mogą być interesujące dla klienta. Sieć ta będzie mogła rozwijać się w trakcie działania aktualnych serwów. Co oznacza że nowe serwery będą mogły się podłączać i rozłączać z sieci nie powodując przy tym problemów.W ramach rzeczy które klient może chcieć otrzymać rozproszona baza danych została udoskonalona o następujące funkcjionalności:
1. set-value <klucz>:<wartość> : ustawienie nowej wartości (drugi parametr) dla klucza
będącego pierwszym parametrem. Wynikiem operacji jest komunikat OK jeśli operacja się
powiodła lub ERROR jeśli baza nie zawiera żadnej pary, w której występuje żądany klucz. Jeśli
w bazie jest kilka rekordów o takim samym kluczu, zmianie musi ulec co najmniej jeden z nich.
2. get-value <klucz> : pobranie wartości dla klucza będącego parametrem w bazie.
Wynikiem operacji jest komunikat składający się z pary <klucz>:<wartość> jeśli operacja
się powiodła lub ERROR jeśli baza nie zawiera żadnej pary, w której występuje żądany klucz.
Jeśli baza zawiera więcej niż jedną parę z takim kluczem, tylko jeden wynik musi zostać
zwrócony (którykolwiek).
3. find-key <klucz> : zlecenie wyszukania adresu i numeru portu węzła, na którym
przechowywany jest rekord o zadanym kluczu. Jeśli taki węzeł istnieje, odpowiedzią jest para
postaci <adres>:<port> identyfikująca ten węzeł lub komunikat ERROR jeśli żaden węzeł
takiego klucza nie posiada. Jeśli baza zawiera więcej niż jedną parę z takim kluczem, tylko
jeden wynik musi zostać zwrócony (którykolwiek).
4. get-max : znalezienie największej wartości przypisanej do wszystkich kluczy w bazie.
Wynikiem operacji jest komunikat składający się z pary <klucz>:<wartość>. Jeśli baza
zawiera więcej niż jedną parę z takim kluczem, tylko jeden wynik musi zostać zwrócony
(którykolwiek).
5. get-min : znalezienie najmniejszej wartości przypisanej do wszystkich kluczy w bazie.
Wynikiem operacji jest komunikat składający się z pary <klucz>:<wartość>. Jeśli baza
zawiera więcej niż jedną parę z takim kluczem, tylko jeden wynik musi zostać zwrócony
(którykolwiek).
6. new-record <klucz>:<wartość> : zapamiętanie nowej pary klucz:wartość w miejsce pary
przechowywanej na węźle, do którego dany klient jest podłączony. Wynikiem tej operacji jest
komunikat OK.
7. terminate : powoduje odłączenie się węzła od sieci poprzez poinformowanie o tym fakcie
swoich sąsiadów oraz zakończenie pracy. Sąsiedzi węzła poinformowani o zakończeniu przez
niego pracy uwzględniają ten fakt w swoich zasobach i przestają się z nim komunikować.
Przed samym zakończeniem pracy węzeł odsyła do klienta komunikat OK.
8. TerminateAll : powoduje wyłączenie całej rozproszonej bazy danych. Serwer dostaje polecenie, 
wysyła do swoich sąsiadów informacje o swoim wyłączeniu, dając im informacje aby same się wyłączyły
zamykając później swój socket kończąc działanie więzła.
Więcej o tym jest w interfejscie systemu.

Wszelkie działania takie jak komunikacja czy obsługa zleceń następują za pomocą komunikacji TCP. W dokumentacji przedstawiono szczegółowo architekure
systemu. Opisano protokoły komunikacji pomiędzy węzłami,klientami oraz algorytm przesyłania zapytań i uruchamianie całości.

OPIS SYSTEMU
Na rozproszoną bazę danych składa się zbiór procesów rozmieszczonych w sieci. Każdy z procesów
posiada pewien zbiór informacji<klucz,wartość>. Procesy tworzą sieć, w której dany proces jest połączony z co najmniej
jednym innym procesem z sieci. Sieć jest tworzona w sposób przyrostowy poprzez uruchamianie
kolejnych procesów (tworzenie kolejnych węzłów) i podłączanie ich do już istniejącej sieci. Każdy
proces (poza pierwszym) po starcie podpina się do sieci zgodnie z modelem komunikacji TCP
w sieci i oczekuje na ewentualne połączenia od kolejnych nowych składowych systemu (kolejnych
dodawanych węzłów) lub klientów pragnących wykonać operacje na bazie. Komunikacja z
potencjalnymi klientami oraz kolejnymi nowo podłączanymi węzłami odbywa się za pomocą protokołu
TCP. Komunikacja z węzłami tworzącymi sieć w trakcie wykonywania operacji na bazie odbywa się za pomocą TCP.
Wszystkie procesy są symetryczne czyli zarówno przechowują swoje dane jak i przyjmują zlecenia
operacji od klientów. Węzły komunikują się wyłącznie z węzłami, do których same podłączyły się przy
starcie lub tymi, które połączyły się z nimi.

FUNKCJIONALNOŚĆ
Tworzenie nowych węzłów i podłączanie ich do sieci, komunikacja między wezłami i klientami za pomocą protokołu TCP.
Rozszerzanie bazy danych o nowe węzły jak i odłączanie ich i starych.
Klient może poprosić o rzeczy o których więcej w komunikacji klient-serwer
Algorytm przekierowywania zapytań, który umożliwia przekazywanie zapytań do połączonych węzłów w sieci

INTERFEJSY SYSTEMU
Interfejsy użytkownika:
klienci bazy danych mogą wysyłac zapytania/zapytanie i otrzymać odpowiedzi poprzez  interfejsc TCP który umożliwia im połączenie się z serwerem i oczekiwać na odpowiedz od określonego węzła

Interfejsy programistyczne:
węzły mogą się komunikować za pomocą protokołu tcp wysyłając i otrzymując odpowiednie komunikaty. 
Więzły mogą odbierać zapytania od klientów i odpowiadać na nie za pomocą protokołu TCP
Metoda log sprawia że Serwer pokazuje jak wykonuje się polecenie oraz dodaje klarowności do działania serwerów.

Interfejsy systemowe:
System informuje o przebiegu działań za pomocą metody log. Może korzystać z protokołu tcp w celu otrzymania i wysyłania odpowiedzi do węzłów i klientów.
DOKUMENTACJA TECHNICZNA
Potrzebne będzie:
-Java Development Kit (JDK) w wersji co najmniej 1.8

Najpierw aby uruchomić węzeł w cmd i klienta trzeba wejść w ścieżkę gdzie jest projekt potem wejść w cmd do folderu wpisać:
javac DatabaseNode.java
javac DatabaseClient.java
Aby stworzyć i skonfigurować węzeł w sieci, należy uruchomić go z odpowiednimi argumentami w konsoli. Przykład uruchomienia węzła:

java DatabaseNode -tcpport 123 -record 1:112510 
gdzie:
•-tcpport <numer portu TCP> określa numer portu TCP na którym dany węzeł sieci
oczekuje na połączenia od klientów.
• -record <klucz>:<wartość> oznacza parę liczb całkowitych początkowo
przechowywanych w bazie na danym węźle, gdzie pierwsza to klucz a druga to wartość
związana z tym kluczem.


Aby dodać nowy węzeł do już istniejącej sieci, należy uruchomić go z argumentem "-connect" wskazującym adres IP i port istniejącego węzła, do którego ma nawiązać połączenie. Przykład uruchomienia nowego węzła podłączonego do istniejącego węzła o adresie IP "localhost" i porcie 123:

java DatabaseNode -tcpport 401-record 3:300 -connect localhost:123

•-tcpport <numer portu TCP> określa numer portu TCP na którym dany węzeł sieci
oczekuje na połączenia od klientów.
• -record <klucz>:<wartość> oznacza parę liczb całkowitych początkowo
przechowywanych w bazie na danym węźle, gdzie pierwsza to klucz a druga to wartość
związana z tym kluczem. Nie ma wymogu unikalności zarówno klucza jak i wartości.
• [ -connect <adres>:<port> ] oznacza listę innych węzłów już będących w sieci, z
którymi dany węzeł ma się połączyć i z którymi może się komunikować w celu wykonywania
operacji.

aby uruchomić klienta podajemy następujące argumenty:
java DatabaseClient -gateway <adres>:<numer portu TCP>
-operation <operacja z parametrami>

przykład: 
java DatabaseClient -gateway localhost:9991 -operation get-value 17
gdzie:
gateaway localhost:9991 - wysyła żadanie do serwera na porce 9991 i adresie ip localhost
operation get-value 17- czego chce klient od serwera.

komunikacja klient-serwer
klient może wysłać ze swojego portu następujące polecenia:
: set-value <klucz>:<wartość>
serwer po otrzymaniu tego polecenia sprawdza czy posiada klucz którego szuka klient.Jeśli posiada szukany przez kilenta klucz wstawia nową wartość zawartą w poleceniu i odsyła komunikat OK. Jeżeli nie ma tego klucza wysyła do podłączonych pod niego serwerów to polecenie dodając do niego informacje że polecenie jest od serwera, nadaje mu indywidualny numer oraz dodaje go do historij otrzymanych poleceń.
Następnie oczkeuje na odpowiedź od innych serwerów zwracając komunikat OK jeżeli się udało albo ERROR w przeciwnym przypadku.
: get-value <klucz> :
serwer po otrzymaniu tego polecenia sprawdza czy posiada klucz którego szuka klient.Jeżeli posiada ten klucz serwer zwraca swój klucz i wartość. Jeżeli nie ma tego klucza wysyła do podłączonych pod niego serwerów
to polecenie dodając do niego informacje że polecenie jest od serwera, nadaje mu indywidualny numer oraz dodaje go do historij otrzymanych poleceń.
Następnie oczkeuje na odpowiedź od innych serwerów zwracając komunikat klucz:wartość serweru który posiadał ten klucz jeżeli się udało go znaleśc albo ERROR w przeciwnym przypadku.
:find-key <klucz> :
serwer po otrzymaniu tego polecenia sprawdza czy posiada klucz którego szuka klient.Jeśli posiada szukany przez kilenta klucz zwraca komununikat <adres>:<port> gdzie adres to jest adres IP serwera oraz jego port. Jeżeli nie ma tego klucza wysyła do podłączonych pod niego serwerów to polecenie dodając do niego informacje że polecenie jest od serwera, nadaje mu indywidualny numer oraz dodaje go do historij otrzymanych poleceń.
Następnie oczkeuje na odpowiedź od innych serwerów zwracając komunikat <port>jeżeli się udało znaleść określony klucz albo ERROR w przeciwnym przypadku.
: get-max :
Serwer po otrzymaniu polecenia najpierw sprawdza czy to polecenie nie trafiło już tu kiedyś. Jeżeli nie przypisuje maksymalnie dużej wartośći swoją wartość i swój klucz wysyła do podłączonych pod niego serwerów to polecenie dodając do niego informacje że polecenie jest od serwera,dodaje swój numer portu oraz nadaje mu indywidualny numer oraz dodaje go do historij otrzymanych poleceń.
Następnie oczkeuje na odpowiedzi od innych serwerów i dla każdego sprawdza co zwrócił. Jeżeli sprawdzona wartość jest większa od akualnej zapisanej maksymalnej wartości jeżeli tak zamieniamy akutalnie maksymalną wartość i klucz na wartość otrzymaną od innego serweru i analizujemy kolejne odpowiedzi.
Następnie zwracamy komunikat w stylu <klucz>:<wartość> gdzie wartość to maksymalna znaleziona wartość a klucz to klucz tej wartośći
: get-min :
Serwer po otrzymaniu polecenia najpierw sprawdza czy to polecenie nie trafiło już tu kiedyś. Jeżeli nie przypisuje minimalnej wartośći swoją wartość i swój klucz. Wysyła do podłączonych pod niego serwerów to polecenie dodając do niego informacje że polecenie jest od serwera,dodaje swój numer portu oraz nadaje mu indywidualny numer oraz dodaje go do historij otrzymanych poleceń.
Następnie oczkeuje na odpowiedzi od innych serwerów i dla każdego sprawdza co zwrócił. Jeżeli sprawdzona wartość jest mniejsza od akualnej zapisanej najmniejszej wartości zamieniamy akutalnie minimalną wartość i klucz na wartość otrzymaną.
Następnie zwracamy komunikat w stylu <klucz>:<wartość> gdzie wartość to minimalna znaleziona wartość a klucz to klucz tej wartośći.
: new-record <klucz>:<wartość> :
Po otrzymaniu polecenia serwer zamienia podaną warość i klucz na podaną w poleceniu i zwraca OK
: terminate :
Po otrzymaniu tego polecenia serwer wysyła do podłaczonych serwerów informacje o tym aby odłączyły się od niego i sam się wyłącza.

komunikacja serwer-serwer

serwer może otrzymać od innego serweru następujące polecenia:

: find :
po otrzymaniu tego polecenia serwer sprawdza czy polecenie trafiło do historji jeżeli nie sprwadza czy nie posiada szukanego przez serwer klucz jeżeli tak zwraca swoje ip i port, jeżeli nie posiada szukanego klucza wysyła do podłączonych serwerów aby sprawdziły ten klucz u siebie i oczekuje na odpowiedź jeżeli choć jeden serwer znajdzie ten klucz zwraca jego IP oraz port w przeciwym wypadku zwraca komunikat "ERROR"
: setValue :
po otrzymaniu tego polecenia serwer sprawdza czy polecenie trafiło do historji jeżeli nie sprwadza czy nie posiada szukanego przez serwer klucz jeżeli tak zmienia wartość dla tego klucz, jeżeli nie posiada szukanego klucza wysyła do podłączonych serwerów aby sprawdziły ten klucz u siebie i oczekuje na odpowiedź jeżeli choć jeden serwer znajdzie ten klucz zamienia jego wartość na podaną od klienta i zwraca komunikat OK jeżeli się udało lub ERROR.
: getAValue :
po otrzymaniu tego polecenia serwer sprawdza czy poilecenie trafiło do historji jeżeli nie sprwadza czy nie posiada szukanego przez serwer klucz jeżeli tak zwraca swój klucz i wartość. Jeżeli nie posiada szukanego klucza wysyła do podłączonych serwerów aby sprawdziły ten klucz u siebie i oczekuje na odpowiedź jeżeli choć jeden serwer znajdzie ten klucz zwraca jego klucz i wartość w przeciwym wypadku zwraca komunikat "ERROR"
: maxValue :
po otrzymaniu tego polecenia serwer sprawdza czy polecenie trafiło do historji jeżeli nie przypisuje swoją wartość jako maksymalna a klucz maksymalnej wartośći jako swój. Następnie rozsyła pytanie do podłączonych serwerów i oczkekuje na odpowiedź jeżeli wartość odpowiedźi od innego serwera jest większa niż akutalna maksymalna wartość przypisuje ja do aktualnej maksymalnej i klucz tej wartośći oraz kontynułuje sprawdzanie kolejnych odpowiedzi. Po wszyszykim zwraca aktualnie maksymalną wartość i jej klucz.
: minValue :
 po otrzymaniu tego polecenia serwer sprawdza czy polecenie trafiło do historji jeżeli nie sprawdza czy polecenie trafiło do historji jeżeli nie przypisuje swoją wartość jako minimalna a klucz minimalnej wartośći jako swój. Następnie rozsyła pytanie do podłączonych serwerów i oczkekuje na odpowiedź jeżeli wartość odpowiedźi od innego serwera jest mniejsza niż akutalna najmniejsza wartość przypisuje ja do aktualnej minimalnej wartości i klucz tej wartośći orazkontynułuje sprawdzanie kolejnych odpowiedzi. Po wszyszykim zwraca aktualnie najmniejsza wartość i jej klucz.

Algorytmy komunikacji: 

Algorytm komunikacji klient-serwer
Po otrzymaniu polecena od klienta serwer uruchchamia nowy wątek z pomocą klasy ClientHandler która służy do detalicznej obsługi polecenia.
W niej każde możliwe rozpoznawalne polecenie zostaje przesłane od opdowiedniej metody w klasie DatabaseNode. Na przykład jeżeli klient wysłał polecenie Terminate, uruchamia metodę terminate() w klasie DatabaseNode która zwraca odpowiedź.
Algorytm komunikacji serwer-serwer
Po otrzymaniu polecena od serweru serwer uruchchamia nowy wątek z pomocą klasy ClientHandler która służy do detalicznej obsługi polecenia.
wszelkie polecenia od innych serwerów zaczynają się od: fromNode co pozwala na rozpoznanie że polecenie trafiło tu od innego serweru trafia ono wtedy do metody w klasie ClientHandler NodeHandler. Tam uruchamiane są metody w klasie DatabaseNode lecz wiadomo jest że polecenie jest od innego serweru i obsyługiwane jest innaczej. Metody adekwatne do otrzymanego polecenia są uruchamiane i zwracają odpowiedź do metody NodeHandler która zwraca odpowiedź do klasy ClientHandler która zwraca odpowiedź do klienta.

Techiczny(informatyczny) opis projetku 


System działania węzłów zaczyna się od następujących zmiennych 
    private static AtomicLong idQuestion;
    private  final DatabaseNode databaseNode=this;
    private final List<String> connections;
    private final List<String> tasksHisory;
    volatile int  finalKey;
    volatile int value;
    volatile ServerSocket welcomeSocket;
    private volatile boolean isNotTerminated;
    private volatile int port;
    List<String > adresses;
gdzie:
idQuestion- służy do zapewnienia braku zapętlenia jeżeli serwer otrzyma to samo polecenie sprawdzi czy ono już tu nie dotarło.
databaseNode- służy do odbierania danych w innych klasach wartości które są umieszczone w tym węźle
connections,adreasses- służa do otrzymania pary adres:port serweru z którym mają się połączyć i umożliwić konunikację.
tasksHisory- zawiera historię poleceń otrzymanych przez serwer sluży do sprawdzenia czy polecenie już tu kiedyś nie dotarło.
finalKey- klucz serwera.
value- wartość serwera.
welcomeSocket- to socket na którym serwer będzie czekał na polecenia.
isNotTerminated- ta zmienna sprawdza czy przypadkiem serwer nie dostał polecenia wyłączenia jeżeli tak to następuje jej zmiana na false i socket się wyłącza w metodzie klasy DatabaseNode run.
port- port na którym akutalnie nasłuchuje serwer

Jeżeli serwer otrzyma zapytanie na socket tworzy się nowy wątek który uruchamia klasę ClientHandler clientHandler=new ClientHandler(Socket klienta, i tutaj przyjmuje nowy thread i od razu go startuje: new Thread(clientHandler)). W ten sposób obsułga zapytania przechodzi do tej klasyt
ClientHandler posiada następujące zmienne:
	
	Socket clientSocket;
:jest to socket clienta który wysłał zapytanie
    	DatabaseNode databaseNode;
: jest to serwer który otrzymał zapytanie.
    	boolean isTerminated;
Zapewnienie że instrukacja dojdzie do końca w tym serwerze.
    	boolean needToAnswear;
: sprawdza czy potrzebna jest odpowiedź czy wystarczy przeanalizować pytanie wewnątrz serweru
Wszystkie te wartości są opisywane w konsturkorze klasy ClientHandler:
public ClientHandler(Socket clientSocket, DatabaseNode databaseNode) {
        this.clientSocket = clientSocket;
        this.databaseNode = databaseNode;
        isTerminated=true;
        needToAnswear=true;
    }
Później uruchamią się metoda run wywołana z klasy DatabaseNode która posiada następujące zmienne:
	String question="";
: zapytanie otrzymane od klienta
        String response="";
: ewentualna odpowiedź serwera
	BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
: czytanie zlecenia od klienta
        PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
: odpowiedzialne za odpowierdź wysyłana do klienta
     	 String [] partsOfResponse=question.split(" ");  
: Rozdziela zapytanie po spacji
	 needToAnswear=true;
: za każdym razem jak dostanie polecenie domyślnie chce odpowiedzieć

Następnie ClientHandler sprawdza o co prosi klient. Sprawdza switch casem co jest w tablicy partsOfRespone na zerowym indeksie i tutaj są następujące możliwości:
  case "fromNode":
jeżeli początkiem wiadomości jest fromNode przesyłamy zapytanie do metody NodeHandler która anazlizuje odpowiedzi przesyłane od więzłów
która analizuje zapytania prawie tak samo jak od klienta tylko posiada wewnętrze polecenia robiące tak samo. 
case "Terminate"
Czyli polecenie od klienta to wyłącz serwer
 response=databaseNode.terminate();
tutaj odpowiedź otrzymana będzie od serwera który otrzymał zapytanie i wywoływana jest metoda terminate która zmienia wartość isNotTerminated w serwerze przerywając nasłuchiwanie na zapytania później rozsyła informacje do podłączonych serwerów że się wyłącza za pomocą metody 
  public List<Socket> spreadTheTask(String s, String s2) throws IOException{
która ma następujące zmienne:
        List<Socket> connectedSockets = new ArrayList<>();
: jest to po prostu lista socketów do na których będziemy wysyłać/odbierać informacje.
która  dla każdego podłączonego serwera tworzy socket, dodaje do listym odpowiada i obluguje błędy: SocketExeption i ConnectExeption oraz zwaraca listę utworzonych socketów.
Tutaj kończy się działanie metody spreadTheTask i kontynułuje się działanie metody terminate.
Zamykamy socket serwera i zwracamy polecenie wykonania polecenia do ClientHandler: "OK" lub "ERROR" jeżeli coś się nie udało.
Dalej sprawdzamy czy trzeba odpowiedzieć oraz czy odpowiedź nie jest pusta jeżeliodpowiedź jest potrzebna i opdowiedź nie jest pusta to wysyłamy odpowiedź do klienta: "OK" jeżeli operacja się powiodła, "ERROR" jeżeli operacja się nie powiodła. Wszystko zostało obsłużone ClientHandler kończy się wraz z wątkiem a serwer nasłuchuje przez cały czas na kolejne polecenia.
      
case"new-record":
Serwer otrzymał polecenie wstawienia nowej wartości <klucz:wartość>
 response=databaseNode.newRecord(partsOfResponse[1]);
tutaj znowu response będzie odpowiedzią z serwera który przyjął zapytanie ale tyym razem wywołujemy metodę newRecord która przyjmuje nową wartość <klucz:warość>. Metoda ta  najpierw oddziela od siebie klucz:wartość późnie zamienia wartość klucza i wartości serwera na wskazaną przez klienta a potem zwraca komunikat "OK. Dalej sprawdzamy czy trzeba odpowiedzieć oraz czy odpowiedź nie jest pusta jeżeli odpowiedź jest potrzebna i opdowiedź nie jest pusta to wysyłamy odpowiedź do klienta: "OK".Wszystko zostało obsłużone ClientHandler kończy się wraz z wątkiem a serwer nasłuchuje przez cały czas na kolejne polecenia.

case "find-key":
Czyli serwer otrzymał polecenie znalezienia klucza podanego przez klienta.
   int key=Integer.parseInt(partsOfResponse[1]);
przetwarza klucz podany od klienta z tekstu na typ numeryczny Integrier
   response=databaseNode.findKey(key,fromNode,question);
tutaj znowu wywołujemy inna metodę findKey która sprawdza poprzez iterator czy polecenie już nie trafiło do tego serwera, Poźniej jeżeliu polecenie tu nie trafiło to sprawdzamy czy w tym serwerze jest taki klucz, jeżeli jest zwracamy adres serwera + ":" + port serwera. Lecze jeżeli wartość nie zostanie znaleziona sprawdzamy czy jest to wiadomość od węzła czy od klienta. Jeżeli jest od sąsiada  to po prostu rozsyłamy polecenie po sąsiadach oprócz tego od którego otrzymaliśmy zapytanie. Lecz jeżeli jest od klienta nadajemy na początku że wiadomość będzie od serwera, potem jakie to polecenie, klucz którego szuka klient oraz port serwera startowego. oraz idQuestion które nadaje pytaniu unikalna wartość.
Dalej dodajemy zapytanie do histoprji zwiekszamy wartość idQuestion aby kolejne pytania też miały unikalną warość IdQuestion.
Potem oczkeujemy na odpowiedzi od klientów jeżeli choć jeden odpowie zwracamy Adres i port serwera któy posaida ten klucz i wysyłamy do klienta OK lub ERROR jeżeli się nie udało odnaleźć klucza.


case "set-value":
Działa prawie tak samo jak find-key lecz po prostu wstawiamy wartość otrzymaną od klienta na miejsce wartości serweru pod określonym kluczem szukanym przez klienta.
case "get-value":
Działa prawie tak samo jak set-key lecz wyszukuje klucza który podaje klient i serwer odssyła <klucz:wartość> jeżeli jest w bazie taki klucz albo ERROR jeżeli nie znaleziono takiego rekordu.

 case "get-max":
 response=databaseNode.getMax(fromNode,question);
 Czyli ponownie odwołujemy się do metody która znajduje się na serwerze który otrzymał zapytanie
public String getMax(boolean isNode, String massage) throws IOException {
      public String ponieważ zwraca odpowiedź
boolean isNode:
tutaj zmiennta sprawdza czy polecenie jest od serweru czy od klienta
String massage:
Polecenie
Na początku tworzymy zmienne max maxKey. Pierwsza odpowiada za maksymalną wartość a maxKey za klucz serweru który posiadał tą maksymalną wartość
późniejsprawdzamy czy polecenie jest w historji, jeżeli nie ma go w historji sprawdzamy czy wartość na serwerze jest większa niż akutalna maksymalna wartość jeżeli tak  max= wartość serwera maxKey=wartosć klucza tego serwera.
Potem rodzielamy polecenie po spacji i psrawdzamy czy poleceni jest od węzła czy od klienta, jeżeli od węzła to po prostu rozsyłamy wiadomość po sąsiadach
, dodajemy zapytanie do historji zwiększamy idQuestion i oczekujemy na odpowiedź. Potem dla każdej odpowiedzi analizujemy czy wartość w otrzmyanej odpowiedzi jest większa niż akutalna maksymalna wartośc jeżeli tak jest to akutalizmujemy zmienną max i maxKey i zwracamy opdowiedź do oczekującego od na odpowiedzi podmiotu.

case "get-min":
Działa tak samo jak max tylko przy porównywaniu wartości sprawdzamy czy jest mniejsza niż akutalna najmniejsza a nie czy większa

case "TerminateAll":
funkja pozwalająca na terminację całej rozproszonej bazy danych. Jeżeli serwer otrzyma to polecenie rozsyła informacje do sąsiadów aby też się odłączyli a potem sam się wyłącza
  
default:
       log("could not recognize the question ");- co oznacza że serwer nie rozpoznał zapytania od klienta.
                    break;
TESTOWANIE:
Testy działania rozproszenaj bazy danych zamieszcone są w folderze src znajdującym się w folderze DatabaseNode

