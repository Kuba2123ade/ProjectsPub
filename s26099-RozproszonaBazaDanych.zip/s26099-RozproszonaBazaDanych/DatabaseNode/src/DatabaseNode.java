import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

public class DatabaseNode implements Runnable {
    private static AtomicLong idQuestion;
    private  final DatabaseNode databaseNode=this;
    private final List<String> connections;
    private final List<String> tasksHisory;
    volatile int  finalKey;
    volatile int value;
    volatile ServerSocket welcomeSocket;
    private volatile boolean isNotTerminated;
    private volatile int port;
    List<String > adresses;

    public DatabaseNode() throws IOException {
        idQuestion = new AtomicLong(0);
        isNotTerminated = true;
        adresses=new ArrayList<>();
        tasksHisory = new ArrayList<>();
        connections=new ArrayList<>();
    }

    public static void setIdQuestion() {
        idQuestion.getAndIncrement();
    }

    public static void main(String[] args) throws IOException {
        DatabaseNode databaseNode = new DatabaseNode();
        try{
        databaseNode.StartingSerwer(args);
        databaseNode.run();
            }catch(BindException e){
            System.out.println("PORT ALREADY IN USE");
        }


    }

    public static void log(String message) {
        System.out.println("[S]: " + message);
        System.out.flush();

    }

    public void StartingSerwer(String[] args) throws IOException {
        log("Starting");
        InetAddress sa = InetAddress.getByName("LocalHost");
        for(int i=0; i<args.length; i++) {
            switch (args[i]) {
                case "-tcpport":
                    port=Integer.parseInt(args[++i]);
                    log("Server socket opening on port " + port);
                    break;
                case "-connect":
                    String [] strings=args[++i].split(":");
                    adresses.add(strings[0]);
                    connections.add(strings[1]);
                    break;
                case "-record":
                    String [] strings1=args[++i].split(":");
                    this.finalKey = Integer.parseInt(strings1[0]);
                    this.value = Integer.parseInt(strings1[1]);
                    log("key: " + finalKey + " value: " + value);
                    break;
                   }
                   log("key: "+finalKey + ", value: "+value);
        }
        welcomeSocket = new ServerSocket(port, 10, sa);
        //
        for (int i = 0; i < connections.size(); i++) {
            System.out.println(connections.get(i));
            try {
                Socket sonSocket = new Socket(adresses.get(i), Integer.parseInt(connections.get(i)));
                PrintWriter out = new PrintWriter(sonSocket.getOutputStream(), true);
                log("son socket: " + sonSocket.getPort());
                out.println("fromNode connect " + Integer.parseInt(args[1]));
                log("Port Exists");
                out.close();
                sonSocket.close();
            } catch (ConnectException e) {
                log("Not Existing port");
            }
        }
        log("finished creating list of connections");
        //

    }

    public List getConnections() {
        return connections;
    }

    @Override
    public synchronized void run() {
        log("entering run");
        while (isNotTerminated) {
            try {
                log("waiting for connection");
                Socket clientSocket = welcomeSocket.accept();
                //
                //
                log("connetcted to: " + clientSocket.getPort());

                log("connecting client");
                // Połączenie od klienta-uruchomienie obsługi klienta
                ClientHandler clientHandler = new ClientHandler(clientSocket, this);
                new Thread(clientHandler).start();


            } catch (IOException e) {
                if (!welcomeSocket.isClosed()) {
                    System.err.println("Error: Could not accept connection from client or node.");
                    e.printStackTrace();
                }
            }
        }
    }

    public String terminate() {
        try {
            this.isNotTerminated = false;
            log("Spreading info about terminating this serwer");
            List<Socket> sockets=spreadTheTask("fromNode sonTermination " + welcomeSocket.getLocalPort(), "-1");
            for (Socket socket : sockets) {
                socket.close();
            }
            log("work finished closing socket");
            welcomeSocket.close();
            return "OK";
        } catch (IOException e) {
            return "ERROR";
        }
    }

    public String TerminateAll(String question, boolean fromNode) throws IOException {
       log("IM HERE");
        this.isNotTerminated = false;
        List<Socket> sockets = spreadTheTask(question,"-1");
        for (int i = 0; i <sockets.size() ; i++) {
            sockets.get(i).close();
        }
        welcomeSocket.close();
        return fromNode?"":"OK";
    }


    public String newRecord(String s) {
        log("new Record shall be: " + s);
        String[] keyandValue = s.split(":");
        this.finalKey = Integer.parseInt(keyandValue[0]);
        this.value = Integer.parseInt(keyandValue[1]);
        return "OK";
    }

    public List<Socket> spreadTheTask(String s, String s2) throws IOException {
        List<Socket> connectedSockets = new ArrayList<>();
        try{
        try {
            for (int i = 0; i < connections.size(); i++) {
                if (connections.get(i) != s2) {


                    log("Sending task to: " + connections.get(i));
                    Socket nodeSocket = new Socket("LocalHost", Integer.parseInt(connections.get(i)));
                    connectedSockets.add(nodeSocket);
                    PrintWriter out = new PrintWriter(nodeSocket.getOutputStream(), true);
                    out.println(s);
                }
            }
        }catch (ConnectException ignored) {
        }


        }catch (SocketException ignored){

        }
        return connectedSockets;
    }

    public String setValue(int key, int value, boolean isNode, String massage) throws IOException, InterruptedException {
        boolean isInHistory = false;
        String s;
        List<Socket> sockets = new ArrayList<>();
        List<String> answears = new ArrayList();


        for (Iterator<String> it = tasksHisory.iterator(); it.hasNext(); ) {
            String next = it.next();
            if (next.equals(massage)) {
                isInHistory = true;
                break;
            }
        }

        if (!isInHistory) {
            if (key == finalKey) {
                this.value = value;
                log("found key new value is: " + value);
                return "OK";
            }
            String[] partsOfMassage = massage.split(" ");
            if (isNode) {
                s = massage;
                log("parts of massage[3]=" + partsOfMassage[4]);
                sockets = spreadTheTask(s, partsOfMassage[4]);
            } else {
                s = "fromNode setValue " + key + " " + value + " " + welcomeSocket.getLocalPort()+" "+idQuestion;
                sockets = spreadTheTask(s, "-1");
            }

            tasksHisory.add(s);
            idQuestion.getAndIncrement();
            for (int i = 0; i < sockets.size(); i++) {
                try {
                    BufferedReader in = new BufferedReader(new InputStreamReader(sockets.get(i).getInputStream()));
                    answears.add(in.readLine());
                    sockets.get(i).close();
                }catch (SocketException ignored){

                }
            }
            for (int i = 0; i < answears.size(); i++) {
                if (!answears.get(i).equals("ERROR")) {
                    return answears.get(i);
                }
            }
        }
        return "ERROR";
    }


    public String findKey(int number, boolean isNode, String massage) throws IOException, InterruptedException {
      try {
          boolean isInHistory = false;
          List<String> answears = new ArrayList();
          String s = "";
          List<Socket> sockets = new ArrayList<>();

          for (Iterator<String> it = tasksHisory.iterator(); it.hasNext(); ) {
              String next = it.next();
              if (next.equals(massage)) {
                  isInHistory = true;
                  break;
              }

          }
          if (!isInHistory) {

              if (finalKey == number) {
                  return welcomeSocket.getInetAddress().getHostAddress() + ":" + welcomeSocket.getLocalPort();
              }
              if (isNode) {
                  String[] partsOfMassage = massage.split(" ");
                  s = massage;
                  log("parts of massage[3]=" + partsOfMassage[3]);
                  sockets = spreadTheTask(s, partsOfMassage[3]);

              } else {
                  s = "fromNode find " + number + " " + welcomeSocket.getLocalPort()+" "+idQuestion;
                  sockets = spreadTheTask(s, Integer.toString(welcomeSocket.getLocalPort()));
              }
              tasksHisory.add(s);
              idQuestion.getAndIncrement();
              for (int i = 0; i < sockets.size(); i++) {
                  try {
                      BufferedReader in = new BufferedReader(new InputStreamReader(sockets.get(i).getInputStream()));
                      answears.add(in.readLine());
                      sockets.get(i).close();
                  }catch (SocketException ignored){

                  }
              }
              for (int i = 0; i < answears.size(); i++) {
                  if (!answears.get(i).equals("ERROR")) {
                      return answears.get(i);
                  }
              }
          }
      }catch (SocketException Ignored){

      }
        return "ERROR";


    }

    public String getAValue(int key, boolean isNode, String massage) throws IOException {
        boolean isInHistory = false;
        String s;
        List<Socket> sockets = new ArrayList<>();
        List<String> answears = new ArrayList();
try {


    for (Iterator<String> it = tasksHisory.iterator(); it.hasNext(); ) {
        String next = it.next();
        if (next.equals(massage)) {
            isInHistory = true;
            break;
        }
    }

    if (!isInHistory) {
        if (key == finalKey) {

            log("found key returning value: " + value);
            return this.finalKey + ":" + value;
        }
        String[] partsOfMassage = massage.split(" ");
        if (isNode) {
            s = massage;
            log("parts of massage[3]=" + partsOfMassage[3]);
            sockets = spreadTheTask(s, partsOfMassage[3]);
        } else {
            s = "fromNode getAValue " + key + " " + welcomeSocket.getLocalPort()+" "+idQuestion;
            sockets = spreadTheTask(s, "-1");
        }

        tasksHisory.add(s);
        idQuestion.getAndIncrement();
        for (int i = 0; i < sockets.size(); i++) {
            try {
                BufferedReader in = new BufferedReader(new InputStreamReader(sockets.get(i).getInputStream()));
                answears.add(in.readLine());
                sockets.get(i).close();
            }catch (SocketException ignored){

            }
        }
        for (int i = 0; i < answears.size(); i++) {
            if (!answears.get(i).equals("ERROR")) {
                return answears.get(i);
            }
        }
    }
}catch (SocketException Ignored){

}
        return "ERROR";
    }

    public String getMax(boolean isNode, String massage) throws IOException {
        int max = Integer.MIN_VALUE;
        int maxKey = -1;
        try{
        boolean isInHistory = false;
        String s;
        List<Socket> sockets = new ArrayList<>();
        List<String> answears = new ArrayList();


        for (Iterator<String> it = tasksHisory.iterator(); it.hasNext(); ) {
            String next = it.next();
            if (next.equals(massage)) {
                isInHistory = true;
                break;
            }
        }

        if (!isInHistory) {
            if (value > max) {
                max = value;
                maxKey = finalKey;
            }

            String[] partsOfMassage = massage.split(" ");
            if (isNode) {
                s = massage;
                log("parts of massage[3]=" + partsOfMassage[2]);
                sockets = spreadTheTask(s, partsOfMassage[2]);
            } else {
                s = "fromNode maxValue " + welcomeSocket.getLocalPort()+" "+idQuestion;
                sockets = spreadTheTask(s, "-1");
            }
            tasksHisory.add(s);
            idQuestion.getAndIncrement();
            for (int i = 0; i < sockets.size(); i++) {
                try {
                    BufferedReader in = new BufferedReader(new InputStreamReader(sockets.get(i).getInputStream()));
                    answears.add(in.readLine());
                    sockets.get(i).close();
                }catch (SocketException ignored){

                }
            }


            for (int i = 0; i < answears.size(); i++) {
                String[] strings = answears.get(i).split(":");
                int key = Integer.parseInt(strings[0]);
                int value = Integer.parseInt(strings[1]);
                if (value > max) {
                    max = value;
                    maxKey = key;
                }
            }
        }
        }catch (SocketException Ignored){

        }
        return maxKey + ":" + max;

    }

    public String getMin(boolean isNode, String massage) throws IOException {
            int min = Integer.MAX_VALUE;
            int minKey = -1;
            try{
            boolean isInHistory = false;
            String s;
            List<Socket> sockets = new ArrayList<>();
            List<String> answears = new ArrayList();


            for (Iterator<String> it = tasksHisory.iterator(); it.hasNext(); ) {
                String next = it.next();
                if (next.equals(massage)) {
                    isInHistory = true;
                    break;
                }
            }

            if (!isInHistory) {
                if (value < min) {
                    min = value;
                    minKey = finalKey;
                }

                String[] partsOfMassage = massage.split(" ");
                if (isNode) {
                    s = massage;
                    log("parts of massage[3]=" + partsOfMassage[2]);
                    sockets = spreadTheTask(s, partsOfMassage[2]);
                } else {
                    s = "fromNode minValue " + welcomeSocket.getLocalPort()+" "+idQuestion;
                    sockets = spreadTheTask(s, "-1");
                }

                tasksHisory.add(s);
                idQuestion.getAndIncrement();
                for (int i = 0; i < sockets.size(); i++) {
                    try {
                        BufferedReader in = new BufferedReader(new InputStreamReader(sockets.get(i).getInputStream()));
                        answears.add(in.readLine());
                        sockets.get(i).close();
                    }catch (SocketException ignored){

                    }
                }


                for (int i = 0; i < answears.size(); i++) {
                    String[] strings = answears.get(i).split(":");
                    int key = Integer.parseInt(strings[0]);
                    int value = Integer.parseInt(strings[1]);
                    if (value < min) {
                        min = value;
                        minKey = key;
                    }
                }
            }
        }catch (SocketException Ignored){

        }
        return minKey + ":" + min;
    }
}