import javax.xml.crypto.Data;
import java.io.*;
import java.net.Socket;

public class ClientHandler implements Runnable{
    Socket clientSocket;
    DatabaseNode databaseNode;
    boolean isTerminated;
    boolean needToAnswear;

    public ClientHandler(Socket clientSocket, DatabaseNode databaseNode) {
        this.clientSocket = clientSocket;
        this.databaseNode = databaseNode;
        isTerminated=true;
        needToAnswear=true;
    }

    @Override
    public void run() {
        String question="";
        String response="";
        try {
        while (isTerminated){
boolean fromNode =false;
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
            question=in.readLine();
            log(question);
            String [] partsOfResponse=question.split(" ");
            System.out.println(partsOfResponse[0]);
            needToAnswear=true;
            switch(partsOfResponse[0]) {
                case "fromNode":
                    response=NodeHandler(question);
                    //
                    break;
                case "terminate":
                    log("IM HERE 2");
                    response=databaseNode.terminate();
                    break;
                case"new-record":
                    log("sending info for new record: "+partsOfResponse[1]);
                    response=databaseNode.newRecord(partsOfResponse[1]);
                    break;
                case "find-key":
                    int key=Integer.parseInt(partsOfResponse[1]);
                    response=databaseNode.findKey(key,fromNode,question);
                    break;
                case "set-value":
                    String[] keyValue=partsOfResponse[1].split(":");
                    response=databaseNode.setValue(Integer.parseInt(keyValue[0]),Integer.parseInt(keyValue[1]),fromNode,question);
                    break;
                case "get-value":
                    response=databaseNode.getAValue(Integer.parseInt(partsOfResponse[1]),fromNode,question);
                    break;
                case "get-max":
                    response=databaseNode.getMax(fromNode,question);
                    break;
                case "get-min":
                    response=databaseNode.getMin(fromNode,question);
                    break;
                case "TerminateAll":
                    response=databaseNode.TerminateAll("fromNode terminateAll",fromNode);
                    break;
                default:
                    log("could not recognize the question ");
                    break;
            }
            if(needToAnswear&&!response.equals("")) {
                out.println(response);

            }
            clientSocket.close();
            in.close();
            out.close();
            isTerminated = false;
        }



        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
    public synchronized String NodeHandler(String s) throws IOException, InterruptedException {
        boolean fromNode=true;
        String [] massage=s.split(" ");
        String response="";
       log("massage is "+ s);
        switch (massage[1]) {
            case "connect":
                log("Connetcing to node " + massage[2]);
                needToAnswear=false;
                databaseNode.getConnections().add(massage[2]);
                log("connected to node " + massage[2]);
                break;
            case "sonTermination":
                for (int i = 0; i <databaseNode.getConnections().size() ; i++) {
                    if(databaseNode.getConnections().get(i).equals(massage[2])){
                        log("Terminated Son "+databaseNode.getConnections().get(i));
                        databaseNode.getConnections().remove(i);
                    }
                }
                break;
            case "find":
                response=databaseNode.findKey(Integer.parseInt(massage[2]),fromNode,s);
                break;
            case "setValue":
                response=databaseNode.setValue(Integer.parseInt(massage[2]),Integer.parseInt(massage[3]),fromNode,s);
                break;
            case "getAValue":
                response=databaseNode.getAValue(Integer.parseInt(massage[2]),fromNode,s);
                break;
            case "maxValue":
                response=databaseNode.getMax(fromNode,s);
                break;
            case "minValue":
                response=databaseNode.getMin(fromNode,s);
                break;
            case "terminateAll":
                response=databaseNode.TerminateAll(s,fromNode);
                break;
        }
        return response;

    }
    public String merge(String [] a){
        String connected="";
        for (int i = 0; i <a.length ; i++) {
            connected+=a[i]+" ";
        }
        return connected;
    }
    public static void log(String message) {
        System.out.println("[SC]: " + message);
        System.out.flush();
    }
}
