//
// Created by kubak on 5/31/2022.
//

#include "Character.h"

#include <utility>
#include <string>

Character::Character(std::string rodzajSwtorzenia,int sila, int zrecznosc, int hp,std::string nazwa){
    this->rodzajStworzenia=std::move(rodzajSwtorzenia);
    this->sila=sila;
    this->zrecznosc=zrecznosc;
    this->hp=hp;
    this->nazwa=nazwa;
    this->moc="dmg*1.25";

    lvl=0;
    exp=0;
    status=Status::Normal;
    used=isUsed::NotUsed;
}

int Character::getHp() const {
    return hp;
}

void Character::setHp(int hp) {
    Character::hp -= hp;
}

std::ostream & operator<<(std::ostream& os, const Character & dt){
    std::string a="";
    if(dt.status==Status::Dead)
        a="Dead";
    if(dt.status==Status::Normal)
        a="Normal";
    if(dt.status==Status::Uncocious)
        a="Uncocious";
   return os <<'\n'<<"Nazwa Postaci: "<< dt.nazwa << '\n' << "HP:  "<<dt.hp <<" Rodzaj swtorzenia:  "<<dt.rodzajStworzenia<<", lvl:  "<<dt.lvl<<", moc: "<<dt.moc<<", zrecznosc: "<<dt.zrecznosc<<", sila: "<<dt.sila<<", Status: "<< a<<", exp: "<<dt.exp;
}
Character::~Character(){
}

int Character::getLvl() const {
    return lvl;
}

void Character::setLvl(int lvl) {
    Character::lvl = lvl;
}

int Character::getSila() const {
    return sila;
}

void Character::setSila(int sila) {
    Character::sila += sila;
}

int Character::getZrecznosc() const {
    return zrecznosc;
}

const std::string &Character::getMoc() const {
    return moc;
}

void Character::setMoc(const std::string &moc) {
    Character::moc = moc;
}

int Character::getExp() const {
    return exp;
}

bool Character::getisSpecialPowerUsedInRound() const {
    return specialPowerUsedInRound;
}

void Character::setSpecialPowerUsedInRound(bool specialPowerUsedInRound) {
    Character::specialPowerUsedInRound = specialPowerUsedInRound;
}

void Character::setExp(int exp) {
    Character::exp += exp;
}
void Character::setExpbutMinus(int exp) {
    Character::exp-=exp;
}

isUsed Character::getUsed() const {
    return used;
}

const std::string &Character::getNazwa() const {
    return nazwa;
}

void Character::setNazwa(const std::string &nazwa) {
    Character::nazwa = nazwa;
}

void Character::setUsed(isUsed used) {
    Character::used = used;
}

Status Character::getStatus() const {
    return status;
}

const std::string &Character::getRodzajStworzenia() const {
    return rodzajStworzenia;
}

void Character::setRodzajStworzenia(const std::string &rodzajStworzenia) {
    Character::rodzajStworzenia = rodzajStworzenia;
}

void Character::setStatus(Status status) {
    Character::status = status;
}

void Character::setZrecznosc(int zrecznosc) {
    Character::zrecznosc += zrecznosc;
}

void Character::setHpbutAdd(int hp) {
hp+=10;
}





