//
// Created by kubak on 6/1/2022.
//
#ifndef PROJEKTC___ENEMY_H
#define PROJEKTC___ENEMY_H
#include "Character.h"
#include "iostream"
#include "vector"
using namespace  std;
class Enemy {

    string name;
    vector<Character> characters;
public:
    void setName(const string &name);

    const vector<Character> & getCharactersbutConst() const;

    vector<Character> & getCharacters();
    void setCharacters(const vector<Character> &characters);

    Enemy(vector<Character> characters, string name);

    ~Enemy();

    string getName() const;
};


#endif //PROJEKTC___ENEMY_H
