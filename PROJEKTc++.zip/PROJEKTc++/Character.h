//
// Created by kubak on 5/31/2022.
//

#ifndef PROJEKTC___CHARACTER_H
#define PROJEKTC___CHARACTER_H
#include <iostream>
#include <string>
enum Status{ Normal, Charmed, Uncocious, Dead, Infected};
enum isUsed{ Used, NotUsed};

 class Character {
     int sila;
     int zrecznosc;
     int hp;
     int lvl;
     int exp;
     std::string moc;
     bool specialPowerUsedInRound=false;
     isUsed used;
     std::string nazwa;
     Status status;
     std::string rodzajStworzenia;
 public:
     Character(std::string rodzajStworzenia, int sila, int zrecznosc, int hp, std::string nazwa);

     ~Character();

friend std::ostream& operator<<(std::ostream& os, const Character& dt);

     int getZrecznosc() const;

     void setZrecznosc(int zrecznosc);

     int getSila() const;

     void setSila(int sila);

     int getHp() const;

     void setHp(int hp);
     void setHpbutAdd(int hp);

     int getLvl() const;

     void setLvl(int lvl);

     int getExp() const;

     void setExp(int exp);
     void setExpbutMinus(int exp);

     const std::string &getMoc() const;

     void setMoc(const std::string &moc);

     bool getisSpecialPowerUsedInRound() const;

     void setSpecialPowerUsedInRound(bool specialPowerUsedInRound);

     isUsed getUsed() const;

     void setUsed(isUsed used);

     const std::string &getNazwa() const;

     void setNazwa(const std::string &nazwa);

     Status getStatus() const;

     void setStatus(Status status);

     const std::string &getRodzajStworzenia() const;

     void setRodzajStworzenia(const std::string &rodzajStworzenia);

 };

#endif //PROJEKTC___CHARACTER_H
