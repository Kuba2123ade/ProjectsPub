//
// Created by kubak on 6/1/2022.
//

#include "Enemy.h"

#include <utility>
Enemy::Enemy(vector<Character> characters, string name):characters(characters),name(name) {

}

Enemy::~Enemy() {}


 string Enemy::getName() const {
    return name;

}

void Enemy::setName(const string &name) {
    Enemy::name = name;
}

 const vector<Character> & Enemy::getCharactersbutConst() const {
    return characters;
}
vector<Character> & Enemy::getCharacters()  {
    return this->characters;
}

void Enemy::setCharacters(const vector<Character> &characters) {
    Enemy::characters = characters;
}


