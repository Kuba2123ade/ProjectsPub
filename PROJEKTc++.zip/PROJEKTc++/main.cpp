#include <iostream>
#include <vector>
#include <string>
#include <cstdlib>
#include <ctime>
#include <cstdlib>
#include <iostream>
#include <cstring>
#include <conio.h>
#include <unistd.h>
#include <fstream>
#include "Enemy.h"


using namespace std;

vector<Character> charatcerRandomizer(vector <string> monsters, int i) {
/*******************************************************************************
ta funkcja ma za zadanie stwarzać randomowych wrogów, oraz umieszczac wybrane postacie u gracza
zwraca ona vector<Character> który odpowiada za tablice potworow dla gracza/wroga
 ******************************************************************************/

    vector<Character> characters;
    vector<Character> allcharacters;

    Character syreniak{"wodny", 15, 12, 100, "syreniak"};
    Character puferman{"wodny", 12, 10, 110, "pufferman"};
    Character wavesDrifter{"wodny", 16, 9, 100, "wavesDrifter"};
    Character stoneMan{"ziemia", 10, 10, 120, "stoneMan"};
    Character plantMan{"ziemia", 9, 13, 100, "plantMan"};
    Character corrupted{"ziemia", 12, 13, 90, "corrupted"};
    Character flewBy{"powietrze", 9, 15, 100, "flewBy"};
    Character Tornader{"powietrze", 13, 8, 100, "Tornader"};
    Character Infector{"powietrze", 10, 10, 100, "Infector"};
    Character dragon{"ogien", 17, 5, 200, "dragon"};
    Character fireMage{"ogien", 5, 15, 125, "fireMage"};
    Character lavaCreser{"ogien", 10, 12, 90, "lavaCreser"};
    Character IceStatue{"lod", 7, 15, 90, "IceStatue"};
    Character FrozenFairy{"lod", 12, 12, 100, "FrozenFairy"};
    Character IcedMountaun{"lod", 15, 12, 100, "IcedMountaun"};
    Character IronHand{"stal", 9, 9, 130, "IronHand"};
    allcharacters.push_back(syreniak);
    allcharacters.push_back(puferman);
    allcharacters.push_back(wavesDrifter);
    allcharacters.push_back(stoneMan);
    allcharacters.push_back(plantMan);
    allcharacters.push_back(corrupted);
    allcharacters.push_back(flewBy);
    allcharacters.push_back(Tornader);
    allcharacters.push_back(Infector);
    allcharacters.push_back(dragon);
    allcharacters.push_back(fireMage);
    allcharacters.push_back(lavaCreser);
    allcharacters.push_back(IceStatue);
    allcharacters.push_back(FrozenFairy);
    allcharacters.push_back(IcedMountaun);
    allcharacters.push_back(IronHand);


    vector<string> smallMonsters;
    if (i == 0) {
        cout << '\n' << "OTO MOZLIWE POSTACIE DO DODANIA:" << '\n';
        for (int j = 0; j < allcharacters.size(); ++j) {
            cout << allcharacters.at(j);
        }
        while (smallMonsters.size() < 6) {
            string nazwaPotwora;
            cout << '\n' << "podaj nazwe potwora ktorego chcesz dodac: " << '\n';
            cin >> nazwaPotwora;
            for (int j = 0; j < monsters.size(); ++j) {
                if (monsters[j] == nazwaPotwora) {
                    smallMonsters.push_back(nazwaPotwora);
                    monsters.erase(monsters.begin() + j); //sprawia aby potwory sie nie powtorzyły
                }
            }
        }


    } else {

        for (int i = 0; i < 4; ++i) {

            int a = monsters.size() - 1;
            if (a >= 0) {
                int liczba = (std::rand() % a--) + 1;
                smallMonsters.push_back(monsters.at(liczba));
                monsters.erase(monsters.begin() + liczba); //sprawia aby potwory sie nie powtorzyły
            }
        }
        //
        for (int j = 0; j < smallMonsters.size(); ++j) {
            cout << smallMonsters.at(j)<<", ";
        }
        //
    }

    for (int i = 0; i < smallMonsters.size(); ++i) {
        if (smallMonsters.at(i) == "syreniak") {
            characters.push_back(syreniak);
        } else if (smallMonsters.at(i) == "pufferman") {

            characters.push_back(puferman);
        } else if (smallMonsters.at(i) == "wavesDrifter") {

            characters.push_back(wavesDrifter);
        } else if (smallMonsters.at(i) == "stoneMan") {

            characters.push_back(stoneMan);
        } else if (smallMonsters.at(i) == "plantMan") {

            characters.push_back(plantMan);
        } else if (smallMonsters.at(i) == "corrupted") {

            characters.push_back(corrupted);
        } else if (smallMonsters.at(i) == "flewBy") {

            characters.push_back(flewBy);
        } else if (smallMonsters.at(i) == "Tornader") {

            characters.push_back(Tornader);
        } else if (smallMonsters.at(i) == "Infector") {

            characters.push_back(Infector);
        } else if (smallMonsters.at(i) == "dragon") {

            characters.push_back(dragon);
        } else if (smallMonsters.at(i) == "fireMage") {

            characters.push_back(fireMage);
        } else if (smallMonsters.at(i) == "lavaCreser") {

            characters.push_back(lavaCreser);
        } else if (smallMonsters.at(i) == "IceStatue") {

            characters.push_back(IceStatue);
        } else if (smallMonsters.at(i) == "FrozenFairy") {

            characters.push_back(FrozenFairy);
        } else if (smallMonsters.at(i) == "IcedMountaun") {

            characters.push_back(IcedMountaun);
        } else if (smallMonsters.at(i) == "IronHand") {

            characters.push_back(IronHand);
        }
    }
    return characters;
};
void save(Enemy enemy, const vector<Enemy> &enemies){//gdzie enemy to gracz a vektor enemies to wrogowie
    /*******************************************************************************
ta funkcja ma za zadanie zapisać gre jezeli gracz sobie tego zażyczy.
     najpierw zapisuje wszystko zwiazengo z graczem a pozniej z wrogami
 ******************************************************************************/
fstream plik;
    plik.open("zapisGry.txt", ios::out);
plik<<enemy.getName()<<endl;
    for (const Character& character : enemy.getCharacters()) {
        plik<<character.getNazwa()<<endl;
    plik<<character.getRodzajStworzenia()<<endl;
    plik<<character.getSila()<<endl;
    plik<<character.getZrecznosc()<<endl;
    plik<<character.getHp()<<endl;
        if(character.getStatus()==Status::Dead)
            plik << "Dead" << endl;
        else if(character.getStatus()==Status::Uncocious)
            plik << "Uncocious" << endl;
        else if(character.getStatus()==Status::Normal)
            plik << "Normal" << endl;
    plik<<character.getExp()<<endl;
    plik<<character.getLvl()<<endl;

    }
    plik<<enemies.at(0).getName()<<endl;
    plik<<enemies.at(1).getName()<<endl;
    plik<<enemies.at(2).getName()<<endl;
    plik<<enemies.at(3).getName()<<endl;
    for (int i = 0; i <enemies.size() ; ++i) {

        for (const Character &character: enemies.at(i).getCharactersbutConst()) {
            plik << character.getNazwa() << endl;
            plik << character.getRodzajStworzenia() << endl;
            plik << character.getSila() << endl;
            plik << character.getZrecznosc() << endl;
            plik << character.getHp() << endl;
            if(character.getStatus()==Status::Dead)
            plik << "Dead" << endl;
            else if(character.getStatus()==Status::Uncocious)
                plik << "Uncocious" << endl;
            else if(character.getStatus()==Status::Normal)
                plik << "Normal" << endl;
            plik << character.getExp() << endl;
            plik << character.getLvl() << endl;

        }
    }
    exit(0);












};

void attack(Character & attacker,int rodzajAtaku, Character & defender,const Enemy& Player,const vector<Enemy>& enemies){
    /*******************************************************************************
wykonuje atak gracza. Przeciwnicy aby ultawic graczowi wygrana atakuja tylko porstawowymi atakmi, a gracz ma specialny atak i zwykly
******************************************************************************/
bool effeciencyLesser=false;
bool effeciencybigger=false;
double damageMultiplater=1;
if(attacker.getRodzajStworzenia()=="woda"&&defender.getRodzajStworzenia()=="ziemia"||defender.getRodzajStworzenia()=="ogien")
    effeciencybigger= true;
if(attacker.getRodzajStworzenia()=="ziemia"&&defender.getRodzajStworzenia()=="ogien"||defender.getRodzajStworzenia()=="lod"||attacker.getRodzajStworzenia()=="stal")
    effeciencybigger= true;
if(attacker.getRodzajStworzenia()=="powietrze"&&defender.getRodzajStworzenia()=="lod")
    effeciencybigger= true;
if(attacker.getRodzajStworzenia()=="ogien"&&defender.getRodzajStworzenia()=="lod"||defender.getRodzajStworzenia()=="stal")
    effeciencybigger= true;
if(attacker.getRodzajStworzenia()=="lod"&&defender.getRodzajStworzenia()=="ziemia")
    effeciencybigger= true;
if(attacker.getRodzajStworzenia()=="stal"&&defender.getRodzajStworzenia()=="woda"||defender.getRodzajStworzenia()=="powietrze")
    effeciencybigger= true;


if(attacker.getRodzajStworzenia()=="woda"&&defender.getRodzajStworzenia()=="woda")
    effeciencyLesser= true;
    if(attacker.getRodzajStworzenia()=="ziemia"&&defender.getRodzajStworzenia()=="powietrze")
        effeciencyLesser= true;
    if(attacker.getRodzajStworzenia()=="powietrze"&&defender.getRodzajStworzenia()=="ziemia"||defender.getRodzajStworzenia()=="stal")
        effeciencyLesser= true;
    if(attacker.getRodzajStworzenia()=="ogien"&&defender.getRodzajStworzenia()=="woda"||defender.getRodzajStworzenia()=="ziemia")
        effeciencyLesser= true;
    if(attacker.getRodzajStworzenia()=="lod"&&defender.getRodzajStworzenia()=="woda"||defender.getRodzajStworzenia()=="ogien"||defender.getRodzajStworzenia()=="lod")
        effeciencyLesser= true;
    if(attacker.getRodzajStworzenia()=="stal"&&defender.getRodzajStworzenia()=="ogien"||defender.getRodzajStworzenia()=="stal")
        effeciencyLesser= true;

    if(effeciencyLesser)
    damageMultiplater=0.75;
     if(effeciencybigger){
        damageMultiplater=1.5;
    }
    //
    cout<<"przed atakiem: "<<defender.getHp();
    //
    int beforeHp=defender.getHp();
    bool dodge=false;
    auto liczba = (std::rand() % defender.getZrecznosc());
    if(liczba>10)
        dodge= true;


    if(!dodge) {
        if (rodzajAtaku == 1) {

            defender.setHp((attacker.getSila()+10) * damageMultiplater * 1.25);//specialna moc zadaje wiecej obrazen 1.25
            attacker.setSpecialPowerUsedInRound(true);
            defender.setStatus(Status::Uncocious);
            if (defender.getHp() <= 0) {
                defender.setHp(0);
                defender.setStatus(Status::Dead);
                bool everythingfine = true;
                while (everythingfine) {
                    cout << "Czy chcesz zapisac gre?(0-nie, chce grac dalej,1-zapisuje i wychodze)" << endl;
                    int yesOrNot;
                    cin >> yesOrNot;
                    if (yesOrNot == 1) {
                        save(Player,enemies);
                        everythingfine = false;
                    } else if (yesOrNot == 0)
                        everythingfine = false;
                    else cout << "Podano zla liczbe podaj 1(tak chce zapisac gre), 2(chce grac dalej)" << endl;
                }
            }

        }
        if (rodzajAtaku == 0) {
            defender.setHp((attacker.getSila()+10) * damageMultiplater);//specialna moc zadaje wiecej obrazen 1.25
            defender.setStatus(Status::Uncocious);
            if (defender.getHp() <= 0) {
                defender.setHp(0);
                defender.setStatus(Status::Dead);
                attacker.setExp(60);
                bool everythingfine = true;
                while (everythingfine) {
                    cout << "Czy chcesz zapisac gre?(0-nie, chce grac dalej,1-zapisuje i wychodze)" << endl;
                    int yesOrNot;
                    cin >> yesOrNot;
                    if (yesOrNot == 1) {
                        save(Player,enemies);
                        everythingfine = false;
                    } else if (yesOrNot == 0)
                        everythingfine = false;
                    else cout << "Podano zla liczbe podaj 1(tak chce zapisac gre), 2(chce grac dalej)" << endl;
                }
            }
        }
    }

    //
    cout<<" po ataku: "<<defender.getHp();
    //
    if(dodge)
        cout<<endl<<"obronca wykonal UNIK"<<endl;
    cout<<"atakujacy"<<attacker.getNazwa()<<" zadal: "<< beforeHp-defender.getHp()<<"obrazen atakowanej postaci "<<defender.getNazwa()<<endl;









};
bool isEverybodyDead(const vector<Character>& characters, int playerORenemy){
    /*******************************************************************************
ta funkcja sprawdza czy wszcyscy wrogowie lub gracze w zaleznosci od inta sa martwi czy nie
******************************************************************************/
  int ded=0;
    for (int i = 0; i <characters.size() ; ++i) {
        if(characters.at(i).getStatus()==Status::Dead)
            ded++;
    }
    if(playerORenemy==1&& ded==6||playerORenemy==0&&ded==4)//gracz
        return true;
    return false;

};

void printTables(const vector<Character>& character){
    /*******************************************************************************
pokazuje tablice charakerow
******************************************************************************/
    for (const auto & i : character) {
        cout<<i;
    }
}
void atakWroga(vector<Enemy> enemiesObject, int enemy , Enemy *Player){
    /*******************************************************************************
wrog atakuje postacie gracza
******************************************************************************/
    int dedOrStunned=0;
    printf("czas na atak wroga:");
    for (const Character& character: enemiesObject.at(enemy).getCharacters()) {
        if(character.getStatus()==Status::Dead||character.getStatus()==Status::Uncocious)
            ++dedOrStunned;
    }
    if(dedOrStunned<=4){
        bool characterAbleToFight= true;
        int character=0;
        while(characterAbleToFight){
            if(enemiesObject.at(enemy).getCharacters().at(character).getStatus()!=Status::Normal)
                ++character;
            else {
                if(isEverybodyDead(Player->getCharacters(),0)){
                    characterAbleToFight=false;
                }else {
                    bool isPlayerMonsterNotDead=true;
                    int number=0;
                    while(isPlayerMonsterNotDead){
                        if(Player->getCharacters().at(number).getStatus()==Status::Dead&&number<=5)
                            number++;
                        else{
                            attack(enemiesObject.at(enemy).getCharacters().at(character), 0,Player->getCharacters().at(number),*Player,enemiesObject);

                            isPlayerMonsterNotDead=false;
                            characterAbleToFight = false;
                        }
                    }


                }
            }
        }





    }

}
int main() {

    vector<string> monsters{"syreniak", "pufferman", "wavesDrifter", "stoneMan", "plantMan", "corrupted", "flewBy",
                            "Tornader", "Infector", "dragon", "fireMage", "lavaCreser", "IceStatue", "FrozenFairy",
                            "IcedMountaun", "IronHand"};

    vector<string> enemies{"OverruledOne", "Katchiangas", "Fellgus", "Baptius", "Instrigus", "kowadis"};
    vector<string> finalEnemies;
    vector<Character> characters;
    vector<Enemy> enemiesObject;
    auto Player=new Enemy(characters ,"Graczus");

    ifstream  plik;
    string czyWczytac;
    /*******************************************************************************
tutaj sprwadzam czy zapis gry jezeli istnieje to pytam czy go wczytac jezeli go nie ma to po prostu tworzy sie nowa gra
******************************************************************************/
    plik.open("zapisGry.txt");
    if(plik.good()){
        cout<<endl<<"znaleziono zapis gry czy go wczytac? Napisz tak aby wczytac lub nie jezeli chcesz zaczac nowa gre"<<endl;
        bool valueGood= true;

        while(valueGood){
            cin>>czyWczytac;
            if(czyWczytac!="tak"&&czyWczytac!="nie")
                cout<<endl<<"Podano nieprawidlowa wartosc sproboj jeszcze raz"<<endl;
            else valueGood= false;
        }
    }

    if(plik.good()&&czyWczytac=="tak"){
vector<string> zapisGry;
for(string z ; plik>>z  ;){
    zapisGry.push_back(z);
}
        plik.close();
        int smh=1;
        int liczba=0;
        int addedValue=8;
        int counter1 = 1;
        int counter2 = 2;
        int counter3 = 3;
        int counter4 = 4;
        int counter5 = 5;
        int counter6 = 6;
        int counter7 = 7;
        int counter8 = 8;
        while(smh <=6) {

            string nazwa= zapisGry.at(counter1);
            string rodzajStworzenia = zapisGry.at(counter2);
            int sila= stoi(zapisGry.at(counter3));
            int zrecznosc=stoi(zapisGry.at(counter4));
            int hp=stoi(zapisGry.at(counter5));
            Status status;
            if(zapisGry.at(counter6)=="Dead")
                 status=Status::Dead;
            if(zapisGry.at(counter6)=="Uncocious")
                 status=Status::Uncocious;
            if(zapisGry.at(counter6)=="Normal")
                 status=Status::Normal;

            int exp=stoi(zapisGry.at(counter7));
            int lvl=stoi(zapisGry.at(counter8));
            Character character{rodzajStworzenia,sila,zrecznosc,hp,nazwa};
            character.setLvl(lvl);
            character.setExp(exp);
            character.setStatus(status);
            characters.push_back(character);

            counter1 += addedValue;
            counter2 += addedValue;
            counter3 += addedValue;
            counter4 += addedValue;
            counter5 += addedValue;
            counter6 += addedValue;
            counter7 += addedValue;
            counter8 += addedValue;
smh++;
        }
Player=new Enemy(characters,zapisGry.at(0));
characters.clear();
        int nameNum=counter1;
        int enemiescounter=4;
        counter1 += enemiescounter;
        counter2 += enemiescounter;
        counter3 += enemiescounter;
        counter4 += enemiescounter;
        counter5 += enemiescounter;
        counter6 += enemiescounter;
        counter7 += enemiescounter;
        counter8 += enemiescounter;

        smh=1;
        int newcounter=1;
        while(newcounter<=4){

            string name=zapisGry.at(nameNum);
            while(smh <=4) {
                string nazwa = zapisGry.at(counter1);

                string rodzajStworzenia = zapisGry.at(counter2);
                int sila = stoi(zapisGry.at(counter3));
                int zrecznosc = stoi(zapisGry.at(counter4));
                int hp = stoi(zapisGry.at(counter5));
                Status status;
                if (zapisGry.at(counter6) == "Dead")
                    status = Status::Dead;
                if (zapisGry.at(counter6) == "Uncocious")
                    status = Status::Uncocious;
                if (zapisGry.at(counter6) == "Normal")
                    status = Status::Normal;

                int exp = stoi(zapisGry.at(counter7));
                int lvl = stoi(zapisGry.at(counter8));
                Character character{rodzajStworzenia, sila, zrecznosc, hp, nazwa};
                character.setLvl(lvl);
                character.setExp(exp);
                character.setStatus(status);
                characters.push_back(character);

                counter1 += addedValue;
                counter2 += addedValue;
                counter3 += addedValue;
                counter4 += addedValue;
                counter5 += addedValue;
                counter6 += addedValue;
                counter7 += addedValue;
                counter8 += addedValue;
                smh++;
            }
            Enemy enemy{characters,name};
            enemiesObject.push_back(enemy);
            characters.clear();
            nameNum++;
            newcounter++;
        }
    }else {
        /*******************************************************************************
tutaj dzieje sie wybor trudnosci jezeli poziom to medium, to postacie wrogow 2 i 3  maja o 15 hp wiecej a 4 wrog ma u swoich postaci o 20 hp wiecej, jezeli poziom to hard to przeciwnik 2 i 3 posiadca u przeciwnikow  20 hp a czwatry ma po 30
******************************************************************************/
        cout<<endl<<"Wybierz poziom trudnosci gry: eazy(latwy), medium(średni), hard(trudny)"<<endl;
        bool valueisGOOD= true;
        string lvlOfDifficulty;
        while(valueisGOOD){
            cin>>lvlOfDifficulty;
            if(lvlOfDifficulty!="eazy"&&lvlOfDifficulty!="medium"&&lvlOfDifficulty!="hard")
                cout<<endl<<"Napisz: eazy aby zagrac w latwej grze, medium aby zagrac na srednim poziomie trudnosci, hard aby zagrac na wysokim poziomie trudnosci"<<endl;
            else valueisGOOD= false;
        }


        cout<< "Wybierz postaci do gry , dobierz je rozsadnie znajac postaci przecwinikow:" << '\n';
        /*******************************************************************************
 tutaj randomowo wytwarzani sa wrogowie a gracz ma mozliwosc doboru postaci
    ******************************************************************************/
        srand(time(NULL));
        for (int i = 0; i < 4; ++i) {
            int a = enemies.size() - 1;

            if (a >= 0) {
                auto liczba = (std::rand() % a--) + 1;
                finalEnemies.push_back(enemies.at(liczba));
                enemies.erase(enemies.begin() + liczba); //sprawia aby wrogowie sie nie powtorzyli
            }
        }


        Enemy enemy1{charatcerRandomizer(monsters, 1), finalEnemies.at(0)};
        Enemy enemy2{charatcerRandomizer(monsters, 1), finalEnemies.at(1)};
        Enemy enemy3{charatcerRandomizer(monsters, 1), finalEnemies.at(2)};
        Enemy enemy4{charatcerRandomizer(monsters, 1), finalEnemies.at(3)};



        cout << enemy1.getName();
        for (int j = 0; j < enemy1.getCharacters().size(); ++j) {
            cout << enemy1.getCharacters().at(j);
        }

        cout << '\n' << '\n';

        cout << enemy2.getName();
        for (int j = 0; j < enemy2.getCharacters().size(); ++j) {
            cout << enemy2.getCharacters().at(j);
        }

        cout << '\n' << '\n';

        cout << enemy3.getName();
        for (int j = 0; j < enemy3.getCharacters().size(); ++j) {
            cout << enemy3.getCharacters().at(j);
        }

        cout << '\n' << '\n';
        cout << enemy4.getName();
        for (int j = 0; j < enemy4.getCharacters().size(); ++j) {
            cout << enemy4.getCharacters().at(j);
        }

        cout << '\n' << '\n';


        Player = new Enemy(charatcerRandomizer(monsters, 0), finalEnemies.at(3));


        enemiesObject.push_back(enemy1);
        enemiesObject.push_back(enemy2);
        enemiesObject.push_back(enemy3);
        enemiesObject.push_back(enemy4);
        if(lvlOfDifficulty=="medium"){
            for (Character character: enemiesObject.at(2).getCharacters()) {
                character.setHpbutAdd(15);
            }
            for (Character character: enemiesObject.at(3).getCharacters()) {
                character.setHpbutAdd(15);
            }
            for (Character character: enemiesObject.at(3).getCharacters()) {
                character.setHpbutAdd(20);
            }
        }
        if(lvlOfDifficulty=="hard"){
            for (Character character: enemiesObject.at(2).getCharacters()) {
                character.setHpbutAdd(20);
            }
            for (Character character: enemiesObject.at(3).getCharacters()) {
                character.setHpbutAdd(20);
            }
            for (Character character: enemiesObject.at(3).getCharacters()) {
                character.setHpbutAdd(30);
            }
        }
    }

    cout << "Oto twoje wybrane postacie: " << '\n';
    for (int i = 0; i < Player->getCharacters().size(); ++i) {
        cout << Player->getCharacters().at(i);
    }



    int enemy = 0;
    bool ingame = true;
    while (enemy < 4) {
        cout << '\n' << "Rozpoczyna sie walka z graczem: " << enemiesObject.at(enemy).getName() << '\n';
        for (int j = 0; j < enemiesObject.at(enemy).getCharacters().size(); ++j) {
            cout << enemiesObject.at(enemy).getCharacters().at(j);
        }
        int charactersUsed = 0;
        bool areCharactersDead=true;
        while(areCharactersDead) {

            while (charactersUsed <= 4) {

                    string podajCoChceszZrobic;
                    bool czywszystkodobrze = true;
                    while (czywszystkodobrze) {

                        cout <<endl<< " napisz co chcesz zrobić: atak(1), Ewolucja Storzenia (2), Wymiana stworzenia (3) ";
                        cin >> podajCoChceszZrobic;
                        if (podajCoChceszZrobic != "1" && podajCoChceszZrobic != "2" && podajCoChceszZrobic !="3")
                            cout << " Podano zla liczbe  " << '\n';
                        else czywszystkodobrze = false;

                    }

                    if (podajCoChceszZrobic == "1") {
                        //sprwadzenie czy wszystkie potwory gracza nie sa martwe lub nieprzytomne
                        int dedOrStunned=0;
                        for (const Character& character: Player->getCharacters()) {
                            if(character.getStatus()==Status::Dead||character.getStatus()==Status::Uncocious)
                                ++dedOrStunned;
                        }
                        if(dedOrStunned<=4) {
                            string nazwa;
                            int rodzajAtaku;
                            int atakowanaPostac;
                            int liczba = 0;
                            int indeks = 0;
                            bool everythingFine = true;
                            while (everythingFine) {
                                cout << '\n' << " Napisz nazwe potwora ktorego chcesz uzyc, atak jakiego chcesz uzyc(0-zwykly,1-specialna zdolnosc), ktora postac wroga chcesz zaatakowac(0-3)(UWAGA! miej na uwadze ze 4 pierwsze postacie uczesnicza w walce a reszta to rezerwa!!!) ";

                                cin >> nazwa >> rodzajAtaku >> atakowanaPostac;
//
                                for (int i = 0; i < 4; ++i) {
                                    if (Player->getCharacters().at(i).getNazwa() == nazwa)
                                        indeks = i;
                                    else liczba = i;
                                }
                                cout << liczba << "==" << Player->getCharacters().size() - 3;
                                if (liczba == Player->getCharacters().size() - 3)
                                    cout << " nie znaleziono postaci, podaj poprawna nazwe postaci " << endl;

                                if (rodzajAtaku > 1 || rodzajAtaku < 0)
                                    cout <<  " podano zla liczbe podaj rodzaj ataku 0(zwykly atak), 1(moc specialna) ";

                                if (Player->getCharacters().at(indeks).getisSpecialPowerUsedInRound() && rodzajAtaku == 1)
                                    cout << " moc specialna zostala juz uzyta " << endl;

                                if (Player->getCharacters().at(indeks).getStatus() == Status::Uncocious ||
                                    Player->getCharacters().at(indeks).getStatus() == Status::Dead)
                                    cout << " postac nie zyje lub jest ogluszona " << endl;

                                if (atakowanaPostac < 0 || atakowanaPostac > 3)
                                    cout << " Podano zla atakowana postac, postacie maja numery 0,1,2,3 ";
                                else {
                                    if (enemiesObject.at(enemy).getCharacters().at(enemy).getStatus() == Status::Dead)
                                        cout << " potwor jest juz martwy, podaj inny numer potwora " << endl;
                                }

                                if (indeks >= 0 && indeks <= 4 && atakowanaPostac >= 0 && atakowanaPostac <= 3)
                                    if (Player->getCharacters().at(indeks).getNazwa() == nazwa && rodzajAtaku == 0 &&
                                        Player->getCharacters().at(indeks).getStatus() == Status::Normal &&
                                        atakowanaPostac >= 0 &&
                                        atakowanaPostac <= 3 &&
                                        enemiesObject.at(enemy).getCharacters().at(atakowanaPostac).getStatus() != Status::Dead) {
                                        attack(Player->getCharacters().at(indeks), rodzajAtaku,
                                               enemiesObject.at(enemy).getCharacters().at(atakowanaPostac),*Player,enemiesObject);
                                        everythingFine = false;
                                    }
                                if (Player->getCharacters().at(indeks).getNazwa() == nazwa && rodzajAtaku == 1 &&
                                    !(Player->getCharacters().at(indeks).getisSpecialPowerUsedInRound()) &&
                                    Player->getCharacters().at(indeks).getStatus() == Status::Normal && atakowanaPostac >= 0 &&
                                    atakowanaPostac <= 3 &&
                                    enemiesObject.at(enemy).getCharacters().at(atakowanaPostac).getStatus() != Status::Dead) {

                                    attack(Player->getCharacters().at(indeks), rodzajAtaku,
                                           enemiesObject.at(enemy).getCharacters().at(atakowanaPostac),*Player,enemiesObject);
                                    everythingFine = false;
                                }


                            }
                        }

                        atakWroga(enemiesObject, enemy, Player);
                    } else if (podajCoChceszZrobic == "2") {
                        if(!isEverybodyDead(Player->getCharacters(),1)) {
                            bool everythingFine = true;
                            int mozliweEwolucje = 0;
                            while (everythingFine) {
                                cout << " Możesz ewoluowac nastepujace postaci: ";
                                for (const Character &character: Player->getCharacters()) {
                                    if (character.getExp() >= 100) {
                                        cout << character;
                                        ++mozliweEwolucje;
                                    }
                                }


                                if (mozliweEwolucje < 1) {
                                    cout << " Ewolucja jest niemowzliwa, straciles kolejke ";
                                    everythingFine = false;
                                } else {
                                    cout << " wypisz nazwe stworzenia które chcesz ewoluowac: ";
                                    string name;
                                    cin >> name;
                                    int i = 0;
                                    int liczbaSprawdzonychPostaci = 0;
                                    for (auto &character: Player->getCharacters()) {
                                        ++liczbaSprawdzonychPostaci;
                                        if (name == character.getNazwa()) {
                                            bool valueAccurate = true;
                                            cout << " Oto statystyki ktore mozesz zwiekszyc, oto możliwości, napisz: "
                                                 << endl
                                                 << " hp aby zwiekszyc zdrowie o 10 " << endl
                                                 << " zrecznosc/sila aby zwiekszyc statystyke o 2 " << endl;

                                            while (valueAccurate) {
                                                string statystyka;
                                                cin >> statystyka;
                                                if (statystyka == "hp") {
                                                    cout << "gratulacje hp zwiekszono o 10 " << endl;
                                                    character.setHpbutAdd(10);
                                                    character.setExpbutMinus(100);
                                                    i = 1;
                                                    valueAccurate = false;
                                                    everythingFine = false;
                                                } else if (statystyka == "zrecznosc") {
                                                    cout << " gratulacje zrecznosc zwiekszono o 2 " << endl;
                                                    character.setZrecznosc(2);
                                                    character.setExpbutMinus(100);
                                                    i = 1;
                                                    valueAccurate = false;
                                                    everythingFine = false;
                                                } else if (statystyka == "sila" ) {

                                                    cout << " gratulacje sile zwiekszono o 2 " << endl;
                                                    character.setSila(2);
                                                    character.setExpbutMinus(100);
                                                    i = 1;
                                                    valueAccurate = false;
                                                    everythingFine = false;
                                                } else
                                                    cout<< " podano zla statystyke napisz hp aby zwiekszyc je o 1-, zrecznosc/sila aby zwiekszyc te statystyki o 2 ";
                                            }
                                        }
                                    }
                                    if (i == 0)
                                        cout << "Podano nieprawidlowe imie";
                                }
                            }
                            atakWroga(enemiesObject, enemy, Player);
                        }else cout<<endl<<" wszysktie postacie nie zyja "<<endl;

                    } else if (podajCoChceszZrobic == "3") {
                        bool everythingfine = true;
                        while (everythingfine) {
                            int aktywnyPotwor = 0;
                            int doZamiany = 0;
                            cout << '\n' << " Oto twoje postacie (1-4)aktywne a od 5 do 6 to te które możesz wymienić : ";
                            cin >> aktywnyPotwor >> doZamiany;

                            if (aktywnyPotwor >= 1 && aktywnyPotwor <= 4 && doZamiany == 5 || doZamiany == 6) {

                                swap(Player->getCharacters().at(aktywnyPotwor - 1),
                                     Player->getCharacters().at(doZamiany - 1));
                                everythingfine = false;

                            } else cout << "Podano złe liczby ";
                        }

                        atakWroga(enemiesObject, enemy, Player);
                        ++charactersUsed;
                    }
                cout<<endl<<" Oto aktualne statystyki twoich postaci: "<<endl;
                printTables(Player->getCharacters());
                cout<<endl<< " Oto statystyki postaci wroga: "<< endl;
                printTables(enemiesObject.at(enemy).getCharacters());
                }

            int amountOfDeadEnemiesMonsters = 0;
            for (int i = 0; i < enemiesObject.size(); ++i) {
                if (enemiesObject.at(enemy).getCharacters().at(i).getStatus() == Status::Dead)
                    ++amountOfDeadEnemiesMonsters;

            }
            if (amountOfDeadEnemiesMonsters == 4) {
                cout << endl << " Gratulacje wygrales Walke z " << enemiesObject.at(enemy).getName() << endl;
                areCharactersDead = false;
            }
            amountOfDeadEnemiesMonsters = 0;
            for (int i = 0; i < Player->getCharacters().size(); ++i) {
                if (Player->getCharacters().at(i).getStatus() == Status::Dead)
                    ++amountOfDeadEnemiesMonsters;
            }
            if (amountOfDeadEnemiesMonsters == 6) {
                cout << endl << "Przegrales walke z " << enemiesObject.at(enemy).getName()
                     << " koniec gry sproboj jeszcze raz!" << endl;
                areCharactersDead = false;
                exit(0);
            }
            //resetowanie statusu bo nowa runda nadchodzi
            for (int i = 0; i <Player->getCharacters().size() ; ++i) {
                if(Player->getCharacters().at(i).getStatus()!=Status::Dead)
                Player->getCharacters().at(i).setStatus(Status::Normal);
            }

            for (Character character: enemiesObject.at(enemy).getCharacters()) {
            if(character.getStatus()!=Status::Dead)
                character.setStatus(Status::Normal);
            }
            charactersUsed=0;
        }
        ++enemy;
    }
    delete Player;
}