Program jest grą RPG, w której gracz może stworzyć zespół postaci i walczyć z wrogami. Gra oferuje możliwość losowego generowania wrogów oraz umieszczania wybranych postaci u gracza. Istnieje także opcja zapisu gry, aby gracz mógł kontynuować rozgrywkę później.
Postacie i wrogowie posiadają różne cechy takie jak rodzaj stworzenia, siła, zręczność, punkty życia (hp), status (żywy, nieprzytomny, martwy), doświadczenie (exp) i poziom (lvl).
Funkcja save służy do zapisu gry, zapisuje stan gracza (jego postacie) oraz wrogów.
Po zapisaniu gry program kończy działanie (funkcja exit(0)), należy to uwzględnić, aby gracz wiedział, że gra się zakończyła po zapisie.
Bardzo polecam wypróbować tą grę gdyż polega na używaniu commandline lecz jest w niej wiele systemów które umilają rozgrywkę i sprawiają że można grać w nią długo.

Jak uruchomić grę:

Skompiluj program, używając odpowiedniego kompilatora dla języka C++.
Uruchom skompilowany plik wykonywalny.
Gra wyświetli listę dostępnych postaci. Gracz może wybrać postacie do dodania do swojego zespołu lub kontynuować bez dodawania.
Następnie program wygeneruje wrogów, których gracz będzie musiał pokonać.
Gra zapisze stan gry w pliku "zapisGry.txt".
