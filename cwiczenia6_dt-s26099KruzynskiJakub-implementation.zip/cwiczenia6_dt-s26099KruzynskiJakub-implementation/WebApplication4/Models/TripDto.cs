﻿using System.ComponentModel.DataAnnotations;
using WebApplication4.Models;

public class TripDto : Trip
{
    [Required]
    public int IdTrip { get; set; }
    [Required]
    public string Name { get; set; } = null!;
    [Required]
    public string Description { get; set; } = null!;
    [Required]
    public DateTime DateFrom { get; set; }
    [Required]
    public DateTime DateTo { get; set; }
    [Required]
    public int MaxPeople { get; set; }
    [Required]
    public new List<ClientDto> Clients { get; set; }
    [Required]
    public new List<CountryDto> Countries { get; set; }
}

public class ClientDto
{
    [Required]
    public string FirstName { get; set; }
    [Required]
    public string LastName { get; set; }
}

public class CountryDto
{
    [Required]
    public string Name { get; set; }
}
