﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication4.Models
{
    public class TripClientAssigment
    {
        [Required]
        public string FirstName { get; set; } = null!;
        [Required]
        public string LastName { get; set; } = null!;
        [Required]
        public string Email { get; set; } = null!;
        [Required]
        public string Telephone { get; set; } = null!;
        [Required]
        public string Pesel { get; set; } = null!;
        [Required]
        public int IdTrip { get; set; }
        [Required]
        public string TripName { get; set; }
        [Required]
        public DateTime PaymentDate { get; set; }
    }
}
