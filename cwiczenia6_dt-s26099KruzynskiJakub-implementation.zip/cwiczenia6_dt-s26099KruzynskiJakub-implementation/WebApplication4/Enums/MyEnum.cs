﻿namespace WebApplication4.Enums
{
    public enum MyEnum
    {
        Ok,
        NotFound,
        InternalSerwerError,
        BadRequest,
        Conflict,

    }
}
