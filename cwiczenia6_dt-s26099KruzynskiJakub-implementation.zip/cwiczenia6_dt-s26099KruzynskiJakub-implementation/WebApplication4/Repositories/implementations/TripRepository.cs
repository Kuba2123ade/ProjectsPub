﻿using Microsoft.EntityFrameworkCore;
using WebApplication4.Enums;
using WebApplication4.Models;
using WebApplication4.Repositories.interfaces;

namespace WebApplication4.Repositories.implementations
{
    public class TripRepository: ITripRepository
    {
        private readonly MasterContext _context;
        public TripRepository(MasterContext context)
        {
            _context = context;
        }

        public async Task<(MyEnum, string)> AssignClientToTripAsync(int id, TripClientAssigment cliente)
        {
            if (id != cliente.IdTrip) { return (MyEnum.BadRequest, $"id {id} does not match {cliente.IdTrip}.Values need to be the same"); }

            var trip = await _context.Trips.FindAsync(id);
            if (trip == null)
            {
                return (MyEnum.NotFound, "The specified trip does not exist.");
            }


            int clientId = 0;
            var client = await _context.Clients.FirstOrDefaultAsync(c => c.Pesel == cliente.Pesel);
            if (client == null)
            {
                clientId = _context.Clients.Max(cx => cx.IdClient) + 1;
                var addedClient = new Client
                {
                    IdClient = clientId,
                    FirstName = cliente.FirstName,
                    LastName = cliente.LastName,
                    Email = cliente.Email,
                    Telephone = cliente.Telephone,
                    Pesel = cliente.Pesel
                };
                _context.Clients.Add(addedClient);
            }
            else clientId = client.IdClient;


            var isRegistered = await _context.ClientTrips.FirstOrDefaultAsync(x => x.IdTripNavigation.IdTrip == id && x.IdClientNavigation.IdClient == clientId);
            if (isRegistered != null)
            {
                return (MyEnum.BadRequest, "The specified client is already registered for the trip.");
            }


            var clientTrip = new ClientTrip
            {
                IdClient = clientId,
                IdTrip = id,
                PaymentDate = cliente.PaymentDate,
                RegisteredAt = DateTime.Now
            };
            _context.ClientTrips.Add(clientTrip);
            await _context.SaveChangesAsync();

            return (MyEnum.Ok, "Client successfully added to the trip.");
        }
            public async Task<(IEnumerable<Trip>, MyEnum, string)> GetTripsAsync()

            {
                try
                {
                    var trips = await _context.Trips
              .Select(a => new TripDto
              {
                  Name = a.Name,
                  DateFrom = a.DateFrom,
                  DateTo = a.DateTo,
                  Description = a.Description,
                  IdTrip = a.IdTrip,
                  MaxPeople = a.MaxPeople,

                  Clients = a.Clients.Select(s => new ClientDto
                  {

                      FirstName = s.IdClientNavigation.FirstName,
                      LastName = s.IdClientNavigation.LastName,
                  }).ToList(),
                  Countries = a.Countries.Select(g => new CountryDto
                  {
                      Name = g.Name,
                  }).ToList(),
              })
              .OrderByDescending(t => t.DateFrom)
              .ToListAsync();

                    return (trips, MyEnum.Ok, "ok");
                }
                catch (Exception ex)
                {
                    return (null, MyEnum.InternalSerwerError, "internal serwer error");
                }


            }
        }
    }
