﻿using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using System.Net.Sockets;
using System.Net;
using WebApplication4.Enums;
using WebApplication4.Models;
using WebApplication4.Repositories.interfaces;


namespace WebApplication4.Repositories.implementations
{
    public class ClientRepository : IClientRepository

    {

        private readonly MasterContext _context;
        public ClientRepository(MasterContext context)
        {
            _context = context;
        }

     

        public async Task<(MyEnum, string)> DeleteClientAsync(int idClient)
        {
            try
            {
                if (_context.ClientTrips.Any(ct => ct.IdClient == idClient))
                {

                    return (MyEnum.BadRequest, "Client has associated trips, cannot delete");
                }


                Client client = _context.Clients.Find(idClient);

                if (client == null)
                {

                    return (MyEnum.NotFound, "Client not found");
                }


                _context.Clients.Remove(client);
                _context.SaveChanges();

                return (MyEnum.Ok, "Client deleted");
            }
            catch (Exception ex)
            {
                return (MyEnum.InternalSerwerError, ex.Message);
            }

        }

    


    }


}



