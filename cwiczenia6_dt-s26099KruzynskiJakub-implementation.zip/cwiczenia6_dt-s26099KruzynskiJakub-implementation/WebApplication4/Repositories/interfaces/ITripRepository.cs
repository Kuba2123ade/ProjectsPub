﻿using WebApplication4.Enums;
using WebApplication4.Models;

namespace WebApplication4.Repositories.interfaces
{
    public interface ITripRepository
    {
        public Task<(MyEnum, string)> AssignClientToTripAsync(int id, TripClientAssigment client);
        public Task<(IEnumerable<Trip>, MyEnum, string)> GetTripsAsync();
    }
}
