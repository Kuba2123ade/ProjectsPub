﻿using Microsoft.AspNetCore.Mvc;
using WebApplication4.Enums;
using WebApplication4.Models;

namespace WebApplication4.Repositories.interfaces
{
    public interface IClientRepository
    {
        public Task<(MyEnum, string)> DeleteClientAsync(int id);

    }
}
