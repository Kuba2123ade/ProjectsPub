﻿using Microsoft.AspNetCore.Mvc;
using WebApplication4.Enums;
using WebApplication4.Models;
using WebApplication4.Repositories.implementations;
using WebApplication4.Repositories.interfaces;

namespace WebApplication4.Controllers
{
    public class TripController : ControllerBase
    {
        private readonly ITripRepository _ITripRepository;
        public TripController(ITripRepository tripRepository)
        {
            _ITripRepository = tripRepository;
        }
        [HttpGet("/api/trips")]
        public async Task<IActionResult> GetTripsAsync()
        {
            (IEnumerable<Trip> t, MyEnum e, string s) ans = await _ITripRepository.GetTripsAsync();
            return ans.e.Equals(MyEnum.Ok) ? Ok(ans.t) : StatusCode(500, ans.s);

        }
        [HttpPost("/api/trips/{idTrip}/client")]
        public async Task<IActionResult> AssignClientToTripAsync([FromRoute] int idTrip, [FromBody] TripClientAssigment client)
        {
            (MyEnum e, string b) status = await _ITripRepository.AssignClientToTripAsync(idTrip, client);

            if (status.e.Equals(MyEnum.Ok)) { return Ok(status.b); }
            else if (status.e.Equals(MyEnum.NotFound)) { return NotFound(status.b); }
            else if (status.e.Equals(MyEnum.Conflict)) { return Conflict(status.b); }
            else if (status.e.Equals(MyEnum.BadRequest)) { return BadRequest(status.b); }
            else return StatusCode(500, status.b);
        }
    }
}
