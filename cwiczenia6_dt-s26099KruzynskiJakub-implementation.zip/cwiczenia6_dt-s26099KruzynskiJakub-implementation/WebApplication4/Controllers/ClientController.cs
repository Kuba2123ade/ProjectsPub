﻿using Microsoft.AspNetCore.Mvc;
using WebApplication4.Enums;
using WebApplication4.Models;
using WebApplication4.Repositories.interfaces;

namespace WebApplication4.Controllers
{
    public class ClientController : ControllerBase
    {
        private readonly IClientRepository _clientRepository;
        public ClientController(IClientRepository clientRepository)
        {
            _clientRepository = clientRepository;
        }
    
        [HttpDelete("/api/clients/{idClient}")]
        public async Task<IActionResult> DeleteClientAsync([FromRoute] int idClient)
        {
            (MyEnum status, string massage) status = await _clientRepository.DeleteClientAsync(idClient);
            if (status.status.Equals(MyEnum.Ok))
            {
                return Ok(status.massage);
            }
            else if (status.status.Equals(MyEnum.BadRequest))
            {
                return BadRequest(status.massage);
            }
            else if (status.status.Equals(MyEnum.NotFound))
                return NotFound(status.massage);
            else { return StatusCode(500, status.massage); }
        }
     
    }
}
